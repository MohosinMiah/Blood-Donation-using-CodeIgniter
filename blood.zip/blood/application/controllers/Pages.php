<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {
    function __construct(){
    $data = array();
    $sdata=array();
    parent::__construct();
    $this->load->model('category_model');
    $this->load->model('post_model');
    $this->load->model('media_model');
    $this->load->model('title_model');
    $this->load->model('inbox_model');
    $this->load->model('pages_model');
    $this->load->model('user_model');
    
   }

  public function page()
  {
    $data = array();
    $data['allPages'] = $this->pages_model->pages();
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] ="Add new Page";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);   
$data['main'] = $this->load->view('admin/inc/page/addpage',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
  }

 
public function view($title)
{
        $data['viewpage'] = $this->pages_model->view($title);
    $data['allPages'] = $this->pages_model->pages();

$data['title'] = 'Bangla blog website ';
    $data['titleoption'] = $this->title_model->showtitle();
    $data['mediaoption'] = $this->media_model->showmedia();
    $data['header']=$this->load->view('font/inc/header',$data,TRUE);    $data['sider']=$this->load->view('font/inc/sider','',TRUE);
    $data['catlist'] = $this->category_model->categorylist();
        $data['postlist'] = $this->post_model->postlist();
$data['copyright'] = $this->media_model->showcopyright();

    $data['postbytitle'] = $this->post_model->single($title);
    $data['main']=$this->load->view('font/pages/page',$data,TRUE);
     $data['side']=$this->load->view('font/inc/side',$data,TRUE);
    $data['footer']=$this->load->view('font/inc/footer',$data,TRUE);
    $this->load->view('font/home',$data);
}


public function viewpage($title,$id)
{
  $data = array();
     $data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();
$data['singlepage'] = $this->pages_model->pagesingle($id);
$data['titleoption'] = $this->title_model->showtitle();
         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->alldonorinfo();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();     $data['title'] = 'Blood Donation Club';
     $data['header'] = $this->load->view('font/include/header',$data,TRUE);
     // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
     $data['main'] = $this->load->view('font/page/page',$data,TRUE);
     $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
     $this->load->view('font/blood/home',$data);
}



  public function savepage()
  {

    $data = array();

    // $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
    $data['title'] = $this->input->post('title');
    $data['body'] = $this->input->post('body');
   

  if (empty($data['title']) OR  empty($data['body'])) {
$sdata['message'] = '<span style="color:red;">Field Must not be empty</span>';
$this->session->set_flashdata($sdata);
redirect('pages/page');

}else{
$this->pages_model->savepage($data);    
$sdata['message'] = '<span style="color:green;">Page Save Successfully...</span>';
$this->session->set_flashdata($sdata);
redirect('pages/page');
        
        }

  
}



public function updatepage($id)
{
  $data = array();
  $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
      $data['allPages'] = $this->pages_model->pages();
  $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
  $data['title'] =" Upade Page";
    $data['editpage']= $this->pages_model->editpage($id);

$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);   
$data['main'] = $this->load->view('admin/inc/page/editpoge',$data,TRUE);  
$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}


public function updatecurrentpage()
{
  $data = array();

    // $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
    $data['title'] = $this->input->post('title');
    $data['body'] = $this->input->post('body');
    $data['pageid'] = $this->input->post('pageid');

  if (empty($data['title']) OR  empty($data['body'])) {
$sdata['message'] = '<span style="color:red;">Field Must not be empty</span>';
$this->session->set_flashdata($sdata);
redirect('pages/updatepage/'.$data['pageid']);

}else{
$this->pages_model->updatecurrentpage($data);    
$sdata['message'] = '<span style="color:green;">Page Update Successfully...</span>';
$this->session->set_flashdata($sdata);
redirect('pages/updatepage/'.$data['pageid']);
        
        }

  
}





 public function postlist()
 {
$data = array();
$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg(); $data['title'] ="Post List";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);   
$data['catlist'] = $this->category_model->categorylist();
$data['postlist'] = $this->post_model->postlist();
$data['main'] = $this->load->view('admin/inc/post/postlist',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
 }

public function deletepage($id)
{
  $data = array();
  $this->pages_model->deletepage($id);

$sdata['message'] = '<span style="color:red;">Data Delete Successfully..';

$this->session->set_flashdata($sdata);
redirect('pages/page');

}







public function showpost($id)
{
  $data = array();
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
  $data['title'] =" Edit Post";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);   
$data['catlist'] = $this->category_model->categorylist();
$data['showposbyid'] = $this->post_model->showposbyid($id);
$data['main'] = $this->load->view('admin/inc/post/showpost',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}



}
