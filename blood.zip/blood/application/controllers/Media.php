<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Media extends CI_Controller {
    function __construct(){
   	$data = array();
   	parent::__construct();
   	$this->load->model('media_model');
    $this->load->model('inbox_model');
    $this->load->model('pages_model');
     $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
   }

	public function updatemedia()
	{
$data = array();
        $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg(); $data['title'] ="Update Media";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
$data['mediaoption'] = $this->media_model->showmedia();
$data['main'] = $this->load->view('admin/inc/siteoption/media',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
	}


  public function changemedia()
  {

    $data = array();
            $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
    $data['facebook'] = $this->input->post('facebook');
    $data['twitter'] = $this->input->post('twitter');
   
    $data['mediaid'] = $this->input->post('mediaid');

    if (empty($data['facebook']) OR empty($data['twitter'])) {
         $sdata['message'] = 'Field Must not be empty';

        $this->session->set_flashdata($sdata);

         redirect('media/updatemedia');
    }else{
      $this->media_model->changetitle($data);
      $sdata['message'] = 'Data Update Successfully';

        $this->session->set_flashdata($sdata);

         redirect('media/updatemedia');
    }


  }

// copyright start design part 

  public function updatecopyright()
  {
$data = array();
        $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] ="Update Copyright";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
$data['mediaoption'] = $this->media_model->showcopyright();
$data['main'] = $this->load->view('admin/inc/siteoption/copyright',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
  }

   public function changecopyright()
  {
    $data = array();
            $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
    $data['copyright'] = $this->input->post('copyright');
    $data['id'] = $this->input->post('id');
   

    if (empty($data['copyright'])) {
         $sdata['message'] = 'Field Must not be empty';

        $this->session->set_flashdata($sdata);

         redirect('media/updatecopyright');
    }else{
      $this->media_model->changecopyright($data);
      $sdata['message'] = 'Data Update Successfully';

        $this->session->set_flashdata($sdata);

         redirect('media/updatecopyright');
    }


  }


}