<?php                


defined('BASEPATH') OR exit('No direct script access allowed');

class Author extends CI_Controller {

 function __construct()
		{
			parent::__construct();
			 // $this->load->model('author_model');
			$data = array();
			 $this->clear_all_cache();
		}
	
	
/**
 * Clears all cache from the cache directory
 */
public function clear_all_cache()
{
    $CI =& get_instance();
$path = $CI->config->item('cache_path');

    $cache_path = ($path == '') ? APPPATH.'cache/' : $path;

    $handle = opendir($cache_path);
    while (($file = readdir($handle))!== FALSE) 
    {
        //Leave the directory protection alone
        if ($file != '.htaccess' && $file != 'index.html')
        {
           @unlink($cache_path.'/'.$file);
        }
    }
    closedir($handle);
}

public function addauthor()
{        
         $data['title'] = 'Add   Author Name';
         $data['header'] = $this->load->view('inc/header',$data,TRUE);
         $data['sidebar'] = $this->load->view('inc/sidebar','',TRUE);
         $data['footer'] = $this->load->view('inc/footer','',TRUE);
         $data['content'] = $this->load->view('inc/addauthor','',TRUE);
         $this->load->view('home',$data);


    
}

public function authoradd()
{
    $data['author_name'] = $this->input->post('author');
   if (empty($data['author_name'])) {
       $sdata['msg'] = '<span style="color:red;">Field Mustn not be empty..!</span>';
      $this->session->set_flashdata($sdata);
        redirect('author/addauthor');
   }else{
    $this->author_model->addauthorname($data);
    $sdata['msg'] = '<span style="color:green;">Author Inser Successfully..!</span>';
      $this->session->set_flashdata($sdata);
        redirect('author/addauthor');
   }

}

public function authorlist()
{
         $data['title'] = 'Add   Author Name';
         $data['header'] = $this->load->view('inc/header',$data,TRUE);
         $data['sidebar'] = $this->load->view('inc/sidebar','',TRUE);
         $data['footer'] = $this->load->view('inc/footer','',TRUE);
         $data['getdeptlist'] =  $this->author_model->authorlist();
         $data['content'] = $this->load->view('inc/authorlist',$data,TRUE);
         $this->load->view('home',$data);

   
}

public function editauthor($id)
{
     $data['title'] = 'Update   Author Name';
         $data['header'] = $this->load->view('inc/header',$data,TRUE);
         $data['sidebar'] = $this->load->view('inc/sidebar','',TRUE);
         $data['footer'] = $this->load->view('inc/footer','',TRUE);
        $data['getauthorbyid'] =  $this->author_model->showauthorbyid($id);

         $data['content'] = $this->load->view('inc/updateauthor',$data,TRUE);
         $this->load->view('home',$data);
}

public function updateauthor()
{
   $data['author_name'] = $this->input->post('author');
   $data['author_id'] = $this->input->post('suthid');
   if (empty($data['author_name'])) {
       $sdata['msg'] = '<span style="color:red;">Field Mustn not be empty..!</span>';
      $this->session->set_flashdata($sdata);
        redirect('author/editauthor/'.$data['author_id']);
   }else{
    $this->author_model->updateauthorin($data);
    $sdata['msg'] = '<span style="color:green;">Author Update Successfully..!</span>';
      $this->session->set_flashdata($sdata);
        redirect('author/editauthor/'.$data['author_id']);
   }
}

public function deleteauthor($id)
{
    $this->author_model->deleteauthor($id);

    $sdata['msg'] = '<span style="color:red;">Author Delete Successfully..!</span>';
      $this->session->set_flashdata($sdata);
        redirect('author/authorlist');
}


}