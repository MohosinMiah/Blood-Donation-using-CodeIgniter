<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {
    function __construct(){
   	
   	parent::__construct();
     $data = array();
   $sdata = array();
   	$this->load->model('inbox_model');
   

   $this->load->model('user_model');
   $this->load->model('title_model');
   $this->load->model('media_model');
   $this->load->model('pages_model');
   }


public function index()
	{

$data = array();
     $data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->alldonorinfo();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();  
      $data['allPages'] = $this->pages_model->pages();

  $data['titleoption'] = $this->title_model->showtitle();
    // $data['mediaoption'] = $this->media_model->showmedia();
            // $data['postlist'] = $this->post_model->postlist();
$data['copyright'] = $this->media_model->showcopyright();
$data['header'] = $this->load->view('font/include/header',$data,TRUE);
     // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
     $data['main'] = $this->load->view('font/page/contact',$data,TRUE);
     $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
     $this->load->view('font/blood/home',$data);

	}


	public function sendmessage()
	{
     $data['subject'] =  $this->input->post('subject');
     $data['email'] =  $this->input->post('email');
     $data['body'] =  $this->input->post('body');
    
if (empty($data['subject']) OR empty($data['email']) OR empty($data['body'])) {
	$sdata['message'] = '<span style="color:red;">Field Must not be empty</span>';

$this->session->set_flashdata($sdata);
redirect('contact');
}else{
      
      $this->load->library('email');
              $this->email->from($data['email']);

        $this->email->to('hamza161033@gmail.com');
        $this->email->subject('Here is your info '.$data['subject']);
        $this->email->message($data['body']);
        $this->email->send();
$this->inbox_model->sendmessage($data);
$sdata['message'] = '<span  style="color:green;">Your message send successfully...</span>';

$this->session->set_flashdata($sdata);
redirect('contact');

 

}

}


public function userlist()
        {
        
 $data['title'] ="User List";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
 $data['userlist'] = $this->user_model->userlist(); 
$data['main'] = $this->load->view('admin/inc/user/userlist',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
        }

        public function edituser($id)
        {
        	     
 $data['title'] ="Edit Category ";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
$data['userlist'] = $this->user_model->showuserbyid($id); 
$data['main'] = $this->load->view('admin/inc/user/edituser',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
        }

	public function updateuser()
	{
		
     
        $data['name'] =  $this->input->post('name');
     $data['address'] =  $this->input->post('address');
     $data['Phone'] =  $this->input->post('Phone');
     $data['userId'] =  $this->input->post('userId');
     $data['roll'] =  $this->input->post('roll');
if (empty($data['name']) OR empty($data['address']) OR empty($data['Phone'])   OR empty($data['roll'])) {
  $sdata['message'] = 'Field Must not be empty';

$this->session->set_flashdata($sdata);
redirect('user/edituser/'.$data['userId']);
}else{

  
 $this->user_model->updateuser($data);
  
    $sdata['message'] = 'Data Update Successfully';

$this->session->set_flashdata($sdata);

redirect('user/edituser/'.$data['userId']);
  



}
}


public function deleteuser($id)
{
	$this->user_model->deleteuser($id);
$sdata['message'] = 'Data Delete Successfully';

$this->session->set_flashdata($sdata);

redirect('user/userlist');
}


public function userprofile()
{
           
 $data['title'] ="User Profile";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
$data['userlist'] = $this->user_model->showuserbyid($id); 
$data['main'] = $this->load->view('admin/inc/user/edituser',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}


public function changepassword()
{
        
 $data['title'] =" Change Password ";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
// $data['userlist'] = $this->user_model->showuserbyid($id); 
$data['main'] = $this->load->view('admin/inc/user/changepassword',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}

}

// public function changepass()
// {
// }



