<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

 function __construct()
		{
			parent::__construct();
               $this->load->model('user_model');
            $this->load->model('media_model');
      $this->load->model('pages_model');
      $this->load->model('title_model');
			$data = array();
            $sdata = array();
			 $this->clear_all_cache();
       
		}




public function adminlogin()
{
     $sdata = array();

        $data['email']    =  $this->input->post('email');
        
        $data['password']  =  $this->input->post('password');

if ( empty($data['email']) OR empty($data['password']) ) {
     $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('admin/login');
}else{

if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
    $data['password'] = md5($data['password']);
      $checkuser =  $this->user_model->adminlogin($data);
   if ($checkuser !== FALSE) {
      
        redirect('dashbord');
   }else{

         $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('admin/login');
   }
   
    
    
   
}else{
  $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('admin/login');
}
}
}













    

	public function register()
    {
         $data = array();
         $data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();
     $data['titleoption'] = $this->title_model->showtitle();
         $data['group'] = $this->user_model->bloodgroup();  
         $data['districtall'] = $this->user_model->alldistrict();

         $data['title'] = 'Register';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/register',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
    }
	

    public function registerdoner()
    {
       $data = array();
       
        $data['name']    =  trim($this->input->post('name'));
        $data['email']    =  trim($this->input->post('email'));
        $data['lidistrict']  =  $this->input->post('lidistrict');
        $data['bgroup']  =  $this->input->post('bgroup');
        $data['password']  =  trim($this->input->post('password'));

if (empty($data['name']) OR empty($data['email']) OR empty($data['lidistrict']) OR empty($data['bgroup']) OR empty($data['password']) ) {
     $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('user/register');
}else{

if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
    $checkuniqueemail = $this->user_model->checkemail($data);
    if ($checkuniqueemail) {
        $data['password'] = md5($data['password']);
        $this->user_model->adddonor($data);
    $sdata['msg'] = '<span style="color:green;">Donor  Added Successfully....!</span>';
      $this->session->set_flashdata($sdata);
      $this->load->library('email');

$this->email->from('hamza1610330816@gmail.com', 'Md Hamza');
$this->email->to($data['email']);
$this->email->subject('Blood Donor Club');
$this->email->message('Thank you For Join Us. Always try to help others by giving Blood. ');

$this->email->send();
        redirect('blood');
    }else{
       $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('user/register'); 
    }
 
}else{
    $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('user/register');
}
  
    
   
}
    }



public function sendmessage()
    {
       $data = array();

        $data['name']    =  trim($this->input->post('name'));
        $data['userid']    =  trim($this->input->post('userid'));
        $data['mobile']    =  trim($this->input->post('mobile'));
        $data['subject']  =  $this->input->post('subject');
        $data['message']  =  $this->input->post('message');
        $data['email'] = $this->input->post('email');

if (empty($data['name']) OR empty($data['mobile']) OR empty($data['subject']) OR empty($data['message'])) {
     $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('blood');
}else{
    if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
  $adata = array();
    $adata['name']  = $data['name'];
    $adata['mobile']  = $data['mobile'];
    $adata['subject']  = $data['subject'];
    $adata['message']  = $data['message'];
  $this->user_model->savemessage($adata);
      $this->load->library('email');
   $this->user_model->getemail($data);
   $to = $this->session->userdata('sendmail');
$this->email->from($data['email']);
$this->email->to($to);
$this->email->subject($data['subject']);
$this->email->message('Name  :'.$data['name'].
' Phone Number ' .$data['mobile'].
''. $data['message']

);
$this->email->send();


$sdata['msg'] = '<span style="color:green;">Message Send Successfully....!</span>';
      $this->session->set_flashdata($sdata);
        // redirect('blood');
    }else{
       $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
                // redirect('blood');

    }
}
  
    
   
}
   








public function login()
{
     $sdata = array();

        $data['email']    =  $this->input->post('email');
        
        $data['password']  =  $this->input->post('password');

if ( empty($data['email']) OR empty($data['password']) ) {
     $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('donor/login');
}else{

if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
    $data['password'] = md5($data['password']);
      $checkuser =  $this->user_model->donorlogin($data);
   if ($checkuser !== FALSE) {
      
        redirect('blood');
   }else{

         $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('donor/login');
   }
   
    
    
   
}
}
}



public function logout()
{ 
    $this->session->set_userdata('login',FALSE);
   $this->session->unset_userdata('name');
   $this->session->unset_userdata('email');
   $this->session->unset_userdata('userid');
   $this->session->sess_destroy();
   redirect('donor/login');
}

public function changedonorpass()
{
          $data = array();

         $data['userid']= $this->session->userdata('userid');
         $data['password'] = $this->input->post('password');
         $data['upassword'] = trim($this->input->post('upassword'));
   $data['upassword'] = md5($data['upassword']);
if (empty($data['password']) OR empty($data['upassword'])   ) {
     $sdata['msg'] = '<span style="color:red;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('donor/changepassword');
}else{ 
  $data['password'] = md5($data['password']);
     $this->user_model->passchange($data);
     $this->logout();
//       if($changepass == FALSE){
// $sdata['msg'] = '<span style="color:red;>Password do not change....!</span>';
//       $this->session->set_flashdata($sdata);
//         redirect('donor/changepassword');
        


//       }else{
        // $this->logout();
      // }

 

}


}


public function adddonation()
{
$sdata = array();
$data = array();

 $data['userid'] = $this->session->userdata('userid');
$data['date']    =  trim($this->input->post('date'));
$data['status']    =  trim($this->input->post('status'));
$data['receptaddress']  =  $this->input->post('receptaddress');
        

if (empty($data['date']) OR empty($data['status']) OR empty($data['receptaddress'])  ) {
     $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('donor/add_donationm');
}else{

 $this->user_model->adddondata($data);
$sdata['msg'] = '<span style="color:green;padding:20px;>Add Successfully....!</span>';
$this->session->set_flashdata($sdata);
redirect('donor/history');


}

}



public function request()
{
  $sdata = array();
    $data['name']    =  htmlspecialchars($this->input->post('name'));
        $data['allPages'] = $this->pages_model->pages();

    $data['lidistrict']  =  $this->input->post('lidistrict');
    $data['contact']    =  htmlspecialchars($this->input->post('contact'));
  $data['date']    =  $this->input->post('date');
    $data['amount']    =  htmlspecialchars($this->input->post('amount'));
    $data['about']  =  htmlspecialchars($this->input->post('about'));
  $data['paddress']    =  htmlspecialchars($this->input->post('paddress'));
    $data['bgroup']  =  $this->input->post('bgroup');
   if (empty($data['name']) OR empty($data['lidistrict']) OR empty($data['contact']) 
OR  empty($data['date']) OR empty($data['amount'])  OR empty($data['about']) OR empty($data['paddress']) OR
empty($data['bgroup'])) {
           $sdata['msg'] = '<span style="color:red;">Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
         redirect('blood/request');

   }else{
    $this->user_model->addrequest($data);
    $sdata['msg'] = '<span style="color:green;">Request Successfull....!</span>';
      $this->session->set_flashdata($sdata);
         redirect('blood/request');

   }
}











/**
 * Clears all cache from the cache directory
 */
public function clear_all_cache()
{
    $CI =& get_instance();
$path = $CI->config->item('cache_path');

    $cache_path = ($path == '') ? APPPATH.'cache/' : $path;

    $handle = opendir($cache_path);
    while (($file = readdir($handle))!== FALSE) 
    {
        //Leave the directory protection alone
        if ($file != '.htaccess' && $file != 'index.html')
        {
           @unlink($cache_path.'/'.$file);
        }
    }
    closedir($handle);
}
}
?>