<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Title extends CI_Controller {
    function __construct(){
   	$data = array();
   	parent::__construct();
   	$this->load->model('title_model');
    $this->load->model('inbox_model');
    $this->load->model('pages_model');
     $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
   }

	public function updatetitle()
	{
$data = array();
    $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] ="Update Title";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
$data['titleoption'] = $this->title_model->showtitle();
$data['main'] = $this->load->view('admin/inc/siteoption/title',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
	}


  public function changetitle()
  {
    $data = array();
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
    $data['titleid'] = $this->input->post('ID');
    $data['webtitle'] = $this->input->post('title');
    $data['webslang'] = $this->input->post('slogan');

    if (empty($data['webtitle']) OR empty($data['webslang'])) {
         $sdata['message'] = 'Field Must not be empty';

        $this->session->set_flashdata($sdata);

         redirect('title/updatetitle');
    }else{
      $this->title_model->changetitle($data);
      $sdata['message'] = 'Data Update Successfully';

        $this->session->set_flashdata($sdata);

         redirect('title/updatetitle');
    }


  }

}