<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {
    function __construct(){
   	$data = array();
   	parent::__construct();
   	  $this->load->model('category_model');
    $this->load->model('post_model');
    $this->load->model('media_model');
    $this->load->model('title_model');
    $this->load->model('pages_model');
   }



// post font view Start  *********************

public function index()
  {
        $data['allPages'] = $this->pages_model->pages();

    $data['titleoption'] = $this->title_model->showtitle();
    $data['mediaoption'] = $this->media_model->showmedia();
    $data['header']=$this->load->view('font/inc/header',$data,TRUE);
    $data['sider']=$this->load->view('font/inc/sider','',TRUE);
    $data['keyword'] = $this->input->post('keyword');
      $data['searchposts'] = $this->post_model->searchposts($data);
 $data['catlist'] = $this->category_model->categorylist();
            $data['postlist'] = $this->post_model->postlist();
    $data['main']=$this->load->view('font/post/search',$data,TRUE);
     $data['side']=$this->load->view('font/inc/side',$data,TRUE);
    $data['footer']=$this->load->view('font/inc/footer','',TRUE);
    $this->load->view('font/home',$data);
  }







}

// public function changepass()
// {
// }



