<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashbord extends CI_Controller {
   function __construct(){
   parent::__construct();
   	$data = array();
   	$this->load->model('inbox_model');
    $this->load->model('userr_model');
    $this->load->model('pages_model');

   }

 public function index()
	{
$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
  $data = array();
        $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
 $data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);   
 $data['main'] = $this->load->view('admin/inc/main','',TRUE);   
 $data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
   $this->load->view('admin/home',$data);
	}
}
