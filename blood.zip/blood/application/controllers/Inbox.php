<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inbox extends CI_Controller {
    function __construct(){
   	$data = array();
   	parent::__construct();
   	$this->load->model('inbox_model');
    $this->load->model('pages_model');
   }

public function replay($emailid)
  {
    $data = array();
     $data['subject'] =  $this->input->post('subject');
     $data['email'] =  $this->input->post('email');
     $data['body'] =  $this->input->post('body');
     $data['id'] =  $this->input->post('id');
    
if (empty($data['subject']) OR empty($data['email']) OR empty($data['body'])) {
  $sdata['message'] = '<span style="color:red;">Field Must not be empty</span>';

$this->session->set_flashdata($sdata);
redirect('inbox/replaymessage/'.$data['id']);
}else{
      
      $this->load->library('email');
              $this->email->from('hamza161033@gmail.com');

        $this->email->to($data['email']);
        $this->email->subject($data['subject']);
        $this->email->message($data['body']);
        $this->email->send();
// $this->inbox_model->sendmessage($data);
$sdata['message'] = '<span  style="color:green;">Your message send successfully...</span>';

$this->session->set_flashdata($sdata);
redirect('inbox/replaymessage/'.$data['id']);

 

}

}


public function inboxmessage()
	{
$data = array();
$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
        $data['allPages'] = $this->pages_model->pages();

$data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] ="View Message";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);   
$data['inboxmessagelist'] = $this->inbox_model->inboxmessagelist();
$data['seeninboxmessagelist'] = $this->inbox_model->seeninboxmessagelist();
$data['main'] = $this->load->view('admin/inc/inbox/inbox',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
	}

public function viewmessage($id)
{
  $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
          $data['allPages'] = $this->pages_model->pages();
$data['countallunseenmsg']= $this->inbox_model->totalseenmsg();

  $data['title'] ="view Message ";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);  
 $data['viewemail'] = $this->inbox_model->viewemail($id); 
$data['main'] = $this->load->view('admin/inc/inbox/viewmeg',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}

public function seen()
{
  $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
          $data['allPages'] = $this->pages_model->pages();

  $data['id'] = $this->input->post('id');
  $this->inbox_model->seenmsg($data);
  redirect('inbox/inboxmessage');
}


public function deletemsg($id)
{
  $this->inbox_model->deletemsg($id);
  $sdata = array();
  $sdata['msg'] ="<span style='color:red;'>Message Delete Successfully</span>";
  $this->session->set_flashdata($sdata);
  redirect('inbox/inboxmessage');
}


public function countallunseenmsg()
{ $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
          $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();

}

public function replaymessage($id)
{
  $data = array();
  $data['emailcr'] = $this->inbox_model->emailget($id);
  
$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
        $data['allPages'] = $this->pages_model->pages();

$data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] ="View Message";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar','',TRUE);   
$data['inboxmessagelist'] = $this->inbox_model->inboxmessagelist();
$data['seeninboxmessagelist'] = $this->inbox_model->seeninboxmessagelist();
$data['main'] = $this->load->view('admin/inc/inbox/replay',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
  
  
}








}




