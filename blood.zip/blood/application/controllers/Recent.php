<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Recent extends CI_Controller {

 function __construct()
		{
			parent::__construct();
             $this->load->model('user_model');
             $this->load->model('title_model');
             $this->load->model('media_model');
            $this->load->model('pages_model');
			$data = array();
			 $this->clear_all_cache();
		}
	
	
/**
 * Clears all cache from the cache directory
 */
public function clear_all_cache()
{
    $CI =& get_instance();
$path = $CI->config->item('cache_path');

    $cache_path = ($path == '') ? APPPATH.'cache/' : $path;

    $handle = opendir($cache_path);
    while (($file = readdir($handle))!== FALSE) 
    {
        //Leave the directory protection alone
        if ($file != '.htaccess' && $file != 'index.html')
        {
           @unlink($cache_path.'/'.$file);
        }
    }
    closedir($handle);
}

public function request()
{
     $data = array();

            $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['allrequest'] = $this->user_model->allrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->alldonorinfo();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();       $data['title'] = 'Blood Donation Club';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/blood/allrequest',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}






}
?>