<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Donor extends CI_Controller {

 function __construct()
		{
			parent::__construct();
            $this->load->model('user_model');
            $this->load->model('title_model');
            $this->load->model('media_model');
            $this->load->model('pages_model');
            $this->load->model('userr_model');
             
			$data = array();
			
		}


        public function forgotpassword()
{
  $login =  $this->session->userdata('alogin');
                       if ($login == TRUE) {  
                           redirect('dashbord');
                       }
       $this->load->view('font/user/forgotpass');
}


public function delete($usid,$livdis)
{
 $delete =  $this->userr_model->deletedonor($usid,$livdis);
 if ($delete == TRUE) {
   $sdata['msg'] = '<span style="color:green;padding:20px;>Donor Delete Successfully....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('userr/alldonor');
 }
   

}


public function sendpassword()
{
  $data = array();
  $data['email'] = $this->input->post('email');
  
  $emailocheck = $this->userr_model->checkdonoremail($data);
  if ($emailocheck) {
    $this->load->library('email');
$this->email->from('hamza16103308@gmail.com', 'Md Hamza Khan');
$this->email->to($data['email']);
$this->email->subject('Reset Password');
$password = substr($data['email'], 1,4).rand(1,6);
$data['pass'] = md5($password);
$this->email->message('Your New Password = ',$password);
$this->email->send();
$this->userr_model->updatedonorpassword($data);


  }else{
    $sdata['msg'] = '<span style="color:red;>Email is not valid....!</span>';
      $this->session->set_flashdata($sdata);
    redirect('donor/forgotpassword');
  }

}


	public function register()
    {
         $data = array();
        $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
 $data['allPages'] = $this->pages_model->pages();
 $data['group'] = $this->user_model->bloodgroup();  
         $data['districtall'] = $this->user_model->alldistrict();

         $data['title'] = 'Register';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/register',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
    }
	

   public function registerdoner()
   {
        $data = array();
       
        $data['name']    =  trim($this->input->post('name'));
        $data['email']    =  trim($this->input->post('email'));
        $data['lidistrict']  =  $this->input->post('lidistrict');
        $data['bgroup']  =  $this->input->post('bgroup');
        $data['password']  =  trim($this->input->post('password'));

if (empty($data['name']) OR empty($data['email']) OR empty($data['lidistrict']) OR empty($data['bgroup']) OR empty($data['password']) ) {
     $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('user/register');
}else{

if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)){
    $checkuniqueemail = $this->user_model->checkemail($data);
    if ($checkuniqueemail == FALSE) {
        $data['password'] = md5($data['password']);
        $this->user_model->adddonor($data);
    $sdata['msg'] = '<span style="color:green;">Donor  Added Successfully....!</span>';
      $this->session->set_flashdata($sdata);
      $this->load->library('email');

$this->email->from('hamza1610330816@gmail.com', 'Md Hamza');
$this->email->to($data['email']);
$this->email->subject('Blood Donor Club');
$this->email->message('Thank you For Join Us. Always try to help others by giving Blood. ');

$this->email->send();
        redirect('blood');
    }else{
       $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('user/register'); 
    }
 
}else{
    $sdata['msg'] = '<span style="color:red;padding:20px;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('user/register');
}
  
    
   
}
   }


    public function login()
    {
         $data = array();
     $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

         $data['title'] = 'Login';
        $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/login',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
    }

public function profile()
{
$login =  $this->session->userdata('login');
                       if ($login !== TRUE) {  
                           redirect('donor/login');;
                       }
             $data['allPages'] = $this->pages_model->pages();

     $data = array();
  $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
         $data['lastdonate'] = $this->user_model->lastd($data);
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'View Profile';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/profile',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}
public function viewprofile($id)
{
     $data = array();
     $data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

     $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
         $data['lastdonate'] = $this->user_model->lastd($data);
         $data['donorinfo'] = $this->user_model->donorinformationbyid($id);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'View Profile';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/viewprofile',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}
public function editprofile()
{
$login =  $this->session->userdata('login');
                       if ($login !== TRUE) {  
                           redirect('donor/login');;
                       }

         $data = array();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

    $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
         $data['alldist'] = $this->user_model->alldistrict();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         // $data['districtall'] = $this->user_model->district();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'Edit Profile';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/editprofile',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}

public function updateinfo()

{ 
$login =  $this->session->userdata('login');
                       if ($login !== TRUE) {  
                           redirect('donor/login');;
                       }

    $sdata = array();
$data['mediaoption'] = $this->media_model->showcopyright();
             $data['allPages'] = $this->pages_model->pages();

 $data['titleoption'] = $this->title_model->showtitle();
$data['connected'] = $this->media_model->showmedia();

    $data['email'] =  $this->session->userdata('email');
     $data['userid'] = $this->session->userdata('userid');
    $data['name']    =  htmlspecialchars($this->input->post('name'));
    $data['lidistrict']  =  $this->input->post('lidistrict');
  $data['homdistrict']    =  $this->input->post('homdistrict');
    $data['contact']    =  htmlspecialchars($this->input->post('contact'));
    $data['gender']  =  $this->input->post('gender');
  $data['bdate']    =  $this->input->post('date');
    $data['weight']    =  $this->input->post('weight');
    $data['smoker']  =  $this->input->post('smoker');
  $data['drug']    =  $this->input->post('drug');
    $data['website']    =  htmlspecialchars($this->input->post('website'));
    $data['about']  =  htmlspecialchars($this->input->post('about'));
  $data['paddress']    =  htmlspecialchars($this->input->post('paddress'));
    $data['status']    =  $this->input->post('status');
    $data['bgroup']  =  $this->input->post('bgroup');
  $data['hcountry']    =  $this->input->post('hcountry');
    $data['amessage']    =  $this->input->post('amessage');
   if (empty($data['name']) OR !isset($data['bgroup']) OR empty($data['lidistrict']) OR
empty($data['bgroup']))
 {
     $sdata['msg'] = '<span style="color:red;">* Some Field Must not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
         redirect('donor/editprofile');

    }else{
    $config = array(
        'upload_path' => "./uploads/",
        'allowed_types' => "gif|jpg|png|jpeg",
        'overwrite' => false,
        );  

      $this->load->library('upload', $config);



        if ($this->upload->do_upload('image')){
                
            $upload_data = $this->upload->data();
$uploaded_image_path = base_url("uploads/".$upload_data['file_name']);

$data['image'] = $uploaded_image_path;


     $this->user_model->updatedonarwi($data);
    $sdata['msg'] = '<span style="color:greeb;">Profile Update Successfully....!</span>';
      $this->session->set_flashdata($sdata);
         redirect('donor/editprofile');
   }else{
    $this->user_model->updatedonarwo($data);
    $sdata['msg'] = '<span style="color:greeb;">Profile Update Successfully....!</span>';
      $this->session->set_flashdata($sdata);
         redirect('donor/editprofile');
   }
  }

        

}



public function changepassword()
{
    $data = array();
    $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

         // $email= $this->session->userdata('email');
         // $userid= $this->session->userdata('userid');
         // $data['donorinfo'] = $this->user_model->donorinformation($email,$userid);
         // $data['district'] = $this->user_model->district();
         // $data['country'] = $this->user_model->country();
         // $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'Change Password';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/changepassword',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}



public function add_donationm()
{
    $data = array();
                  $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

         $email= $this->session->userdata('email');
         $userid= $this->session->userdata('userid');
         // $data['donorinfo'] = $this->user_model->donorinformation($email,$userid);
         // $data['district'] = $this->user_model->district();
         // $data['country'] = $this->user_model->country();
         // $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'Add Donation';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/adddonation',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}



public function history()
{
    $data = array();
    $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
             $data['allPages'] = $this->pages_model->pages();

         $data['email']= $this->session->userdata('email');
        $data['userid']= $this->session->userdata('userid');
         $data['history'] = $this->user_model->history($data);

         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'Blood Donation Club';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/user/viewhistory',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}

// new start  *********************

}
?>