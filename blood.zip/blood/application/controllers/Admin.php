<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
   function __construct()
		{
			parent::__construct();
    $this->load->model('inbox_model');
    $this->load->model('userr_model');
    $this->load->model('pages_model');
    $this->load->model('user_model');
			$data = array();
            $sdata = array();
       
		}

	
	public function login()
	{

		$login =  $this->session->userdata('alogin');
                       if ($login == TRUE) {  
                           redirect('dashbord');
                       }
		   $this->load->view('admin/inc/user/login');
	}
	


public function logout()
{ 
    $this->session->set_userdata('alogin',FALSE);
   $this->session->unset_userdata('name');
   $this->session->unset_userdata('email');
   $this->session->unset_userdata('userId');
   $this->session->sess_destroy();
   redirect('admin/login');
}

public function adminchangedonorpass()
{
          $data = array();

         $data['userId']= $this->session->userdata('userId');
         $data['password'] = trim($this->input->post('password'));
         $data['upassword'] = trim($this->input->post('upassword'));
if (empty($data['password']) OR empty($data['upassword'])   ) {
     $sdata['msg'] = '<span style="color:red;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('userr/changepassword');
}else{ 
  $data['password'] = md5($data['password']);
     $data['upassword'] = md5($data['upassword']);

     $this->user_model->adminpasschange($data);
     $this->logout();
//       if($changepass == FALSE){
// $sdata['msg'] = '<span style="color:red;>Password do not change....!</span>';
//       $this->session->set_flashdata($sdata);
//         redirect('donor/changepassword');
        


//       }else{
        // $this->logout();
      // }

 

}


}



public function forgotpassword()
{
  $login =  $this->session->userdata('alogin');
                       if ($login == TRUE) {  
                           redirect('dashbord');
                       }
       $this->load->view('admin/inc/user/forgotten');
}




public function sendpassword()
{
  $data = array();
  $data['email'] = $this->input->post('email');
  
  $emailocheck = $this->userr_model->checkadminemail($data);
  if ($emailocheck) {
    $this->load->library('email');
$this->email->from('hamza16103308@gmail.com', 'Md Hamza Khan');
$this->email->to($data['email']);
$this->email->subject('Reset Password');
$password = substr($data['email'], 1,4).rand(1,6);
$data['pass'] = md5($password);
$this->email->message('Your New Password = ',$password);
$this->email->send();
$this->userr_model->updatepassword($data);


  }else{
    $sdata['msg'] = '<span style="color:red;>Email is not valid....!</span>';
      $this->session->set_flashdata($sdata);
    redirect('admin/forgotpassword');
  }

}


}
