<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blood extends CI_Controller {
 
 function __construct()
 {
 	 $data = array();
 	 $sdata = array();
 	 parent::__construct();
 	 $this->load->model('user_model');
   $this->load->model('title_model');
   $this->load->model('media_model');
   $this->load->model('pages_model');
                 
 }
	
	public function index()
	{
		$this->home();
	}
	public function home()
	{
		 $data = array();
     $data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();

$data['titleoption'] = $this->title_model->showtitle();
         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->alldonorinfo();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();	
         	 $data['title'] = 'Blood Donation Club';
		 $data['header'] = $this->load->view('font/include/header',$data,TRUE);
		 $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
		 $data['main'] = $this->load->view('font/include/main',$data,TRUE);
		 $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
		 $this->load->view('font/blood/home',$data);
	}

public function group($name,$id)
    {

         $data = array();
 $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->ralldonarbybgroup($id);
         $data['onegroup'] = $this->user_model->onegroup($id);

         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();       $data['title'] = 'Blood Donation Club';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
       $data['main'] = $this->load->view('font/blood/donorbygroup',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
    }


  public function ditricts()
  {
      $data = array();
    $data['allPages'] = $this->pages_model->pages();

             $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->alldonorinfo();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();      $data['title'] = 'Blood Donation Club';
       $data['header'] = $this->load->view('font/include/header',$data,TRUE);
       // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
       $data['main'] = $this->load->view('font/blood/alldistrict',$data,TRUE);
       $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
       $this->load->view('font/blood/home',$data);
  }


  public function district($name,$id)
  {
      $data = array();
            $data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->sddonors($id);
         $data['onedis'] = $this->user_model->onedis($id);
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup(); 
              $data['title'] = 'District Donor';
       $data['header'] = $this->load->view('font/include/header',$data,TRUE);
       // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
       $data['main'] = $this->load->view('font/blood/districtdonor',$data,TRUE);
       $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
       $this->load->view('font/blood/home',$data);
  }













public function request()
{
	      $data = array();
$data['titleoption'] = $this->title_model->showtitle();
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();

         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldist'] = $this->user_model->alldistrict();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();
         $data['title'] = 'Blood Donation Club';
         $data['header'] = $this->load->view('font/include/header',$data,TRUE);
         // $data['slider'] = $this->load->view('font/include/slider',$data,TRUE);
         $data['main'] = $this->load->view('font/blood/requestblood',$data,TRUE);
         $data['footer'] = $this->load->view('font/include/footer',$data,TRUE);
         $this->load->view('font/blood/home',$data);
}

	
}
