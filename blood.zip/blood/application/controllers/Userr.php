<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userr extends CI_Controller {
    function __construct(){
   	$data = array();
   	parent::__construct();
   	$this->load->model('userr_model');
    $this->load->model('inbox_model');
    $this->load->model('pages_model');
    $this->load->model('user_model');
    $this->load->model('media_model');
    $this->load->model('title_model');
   }



public function alldonor()
{
$data = array();
$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
$data['mediaoption'] = $this->media_model->showcopyright();
$data['connected'] = $this->media_model->showmedia();
    $data['allPages'] = $this->pages_model->pages();
$data['titleoption'] = $this->title_model->showtitle();
         $data['email']= $this->session->userdata('email');
         $data['userid']= $this->session->userdata('userid');
        $data['numdo'] = $this->user_model->totalhis($data);
         $data['districtall'] = $this->user_model->alldistrict();
         $data['limitrequest'] = $this->user_model->limitrequest();
         $data['donorinfo'] = $this->user_model->donorinformation($data);
         $data['alldonar'] = $this->user_model->alldonorinfo();
         $data['country'] = $this->user_model->country();
         $data['group'] = $this->user_model->bloodgroup();  
$data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
 $data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);   
$data['main'] = $this->load->view('admin/inc/user/alldonor','',TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}





	public function adduser()
	{
$data = array();
$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
        $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();

 $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
 $data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);   
$data['main'] = $this->load->view('admin/inc/user/adduser','',TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
	}

	public function saveuser()
	{
    $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
     $data['name'] =  $this->input->post('name');
     $data['address'] =  $this->input->post('address');
     $data['Phone'] =  $this->input->post('Phone');
     $data['email'] =  $this->input->post('email');
     $data['password'] =  $this->input->post('password');
     $data['roll'] =  $this->input->post('roll');
if (empty($data['name']) OR empty($data['address']) OR empty($data['Phone']) OR empty($data['email']) OR empty($data['password']) OR empty($data['roll'])) {
	$sdata['message'] = 'Field Must not be empty';

$this->session->set_flashdata($sdata);
redirect('userr/adduser');
}else{
if (filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
  $data['password']=md5($data['password']);
	$emailchek =$this->userr_model->insertuser($data);
  if ($emailchek == TRUE) {
    $sdata['message'] = 'This Email is alrady used';

$this->session->set_flashdata($sdata);

redirect('userr/adduser');
  }else{
    $sdata['message'] = 'Data Inserted Successfully';

$this->session->set_flashdata($sdata);

redirect('userr/adduser');
  }




}else{
  $sdata['message'] = 'Enter Valid Email Address';

$this->session->set_flashdata($sdata);

redirect('userr/adduser');
}
}
}


public function userlist()
        {
        $data = array();
        $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
                $data['allPages'] = $this->pages_model->pages();

    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] ="User List";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);  
 $data['userlist'] = $this->userr_model->userlist(); 
$data['main'] = $this->load->view('admin/inc/user/userlist',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
        }

        public function edituser($id)
        {
          $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
        $data['allPages'] = $this->pages_model->pages();
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();

 $data['title'] ="Edit Category ";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);  
$data['userlist'] = $this->userr_model->showuserbyid($id); 
$data['main'] = $this->load->view('admin/inc/user/edituser',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
        }

	public function updateuser()
	{
		$login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
     
        $data['name'] =  $this->input->post('name');
     $data['address'] =  $this->input->post('address');
     $data['Phone'] =  $this->input->post('Phone');
     $data['userId'] =  $this->input->post('userId');
     $data['roll'] =  $this->input->post('roll');
if (empty($data['name']) OR empty($data['address']) OR empty($data['Phone'])   OR empty($data['roll'])) {
  $sdata['message'] = 'Field Must not be empty';

$this->session->set_flashdata($sdata);
redirect('userr/edituser/'.$data['userId']);
}else{

  
 $this->userr_model->updateuser($data);
  
    $sdata['message'] = 'Data Update Successfully';

$this->session->set_flashdata($sdata);

redirect('userr/edituser/'.$data['userId']);
  



}
}


public function deleteuser($id)
{
  $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
	$this->userr_model->deleteuser($id);
$sdata['message'] = '<span class="color:green;">Data Delete Successfully</span>';

$this->session->set_flashdata($sdata);

redirect('userr/userlist');
}


public function userprofile()
{
          $data['allPages'] = $this->pages_model->pages();

 $data['title'] ="User Profile";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);  
$data['userlist'] = $this->userr_model->showuserbyid($id); 
$data['main'] = $this->load->view('admin/inc/user/edituser',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}


public function changepassword()
{
        $data = array();
                $data['allPages'] = $this->pages_model->pages();
 $login =  $this->session->userdata('alogin');
                       if ($login !== TRUE) {  
                           redirect('admin/login');
                       }
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
 $data['title'] =" Change Password ";
$data['header'] = $this->load->view('admin/inc/header',$data,TRUE);
$data['sidebar'] = $this->load->view('admin/inc/sidebar',$data,TRUE);  
// $data['userlist'] = $this->userr_model->showuserbyid($id); 
$data['main'] = $this->load->view('admin/inc/user/changepassword',$data,TRUE);  

$data['footer'] = $this->load->view('admin/inc/footer','',TRUE);    
$this->load->view('admin/home',$data);
}



public function changepass()
{
 
 $data = array();
 
         $data['userid']= $this->session->userdata('userid');
         $data['password'] = $this->input->post('password');
         $data['upassword'] = trim($this->input->post('upassword'));
   $data['upassword'] = md5($data['upassword']);
if (empty($data['password']) OR empty($data['upassword'])   ) {
     $sdata['msg'] = '<span style="color:red;>Field Must Not be Empty....!</span>';
      $this->session->set_flashdata($sdata);
        redirect('donor/changepassword');
}else{ 
  $data['password'] = md5($data['password']);
     $this->user_model->passchange($data);
     $this->logout();


 

}



}



}