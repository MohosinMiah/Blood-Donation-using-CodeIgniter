<footer class="footoption">
                <p>&copy; <a href="http://www.trainingwithliveproject.com/" target="_blank">Training with live project</a></p>
            </footer>
<script src="<?php echo base_url(); ?>lib/bootstrap/js/bootstrap.js"></script>
</body>
</html>
