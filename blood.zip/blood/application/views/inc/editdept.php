<h2>Update Department</h2>
<?php 

  $smg = $this->session->flashdata('msg');
if (isset($smg)) {
   echo $smg;
}

?><?php echo validation_errors(); ?>
			<hr/>
			<?php 

             foreach ($getdeptbyid as $key => $value) {
               
            ?>
        <div class="panel-body" style="width:600px;">
            <form action="<?php echo base_url(); ?>department/updatedept" method="post">

                <div class="form-group">
                    <label>Department Name</label>
                    <input type="hidden" name="deptid" value="<?php echo $value->dept_id;?>">
                    <input type="text" name="dept" value="<?php echo $value->dept_name; ?>" class="form-control span12">
                </div>
               
               
                <div class="form-group">
				<input type="submit"class="btn btn-primary" value="Submit"> 
                </div>
                   
            </form>
        </div>	
        <?php } ?>