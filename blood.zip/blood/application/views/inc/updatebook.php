<h2>Add Student</h2>
<?php 

  $smg = $this->session->flashdata('msg');
if (isset($smg)) {
   echo $smg;
}

?>
			<hr/>
			<?php
        foreach ($getbookbyid as $book) {
          
      ?>
        <div class="panel-body" style="width:600px;">
            <form action="<?php echo base_url(); ?>book/updatebook" method="post">
                <div class="form-group">
                    <label>Book  Name</label>
                    <input type="hidden" name="book_id" value="<?php echo $book->book_id; ?>">
                    <input type="text" name="name" value="<?php echo $book->book_name; ?>" class="form-control span12">
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select name="dept" id="" class="form-control span12">
                      <option>Slect Department</option>

                        <?php 

            foreach ($getdeptlist as  $dept) {
                  ?>
                        <option
<?php 
       if ($book->book_dept == $dept->dept_id) { echo 'selected'; }
 ?>

                         value="<?php echo $dept->dept_id; ?>"><?php echo $dept->dept_name; ?></option>
                         <?php 
}                                                                                                                                                                                                                        
                         ?>
                    </select>
                </div>
                 <div class="form-group">
                    <label>Author</label>
                    <select name="auth" id="" class="form-control span12">
                    <option>Select Author</option>
                       <?php 
            foreach ($getauthorlist as  $author) {
//               if ($book->book_author == $author->author_id) {


//              echo 'selected';
// }

                         ?>
                        <option
 <?php 
       if ($book->book_author == $author->author_id) { echo 'selected'; }
 ?>
                         value="<?php echo $author->author_id; ?>"><?php echo $author->author_name; ?></option>
                         <?php } ?>
                    </select>
                </div>
                                        <?php } ?>

                <div class="form-group">
				<input type="submit"class="btn btn-primary" value="Submit"> 
                </div>
                   
            </form>
        </div>	