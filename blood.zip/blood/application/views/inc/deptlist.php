  <h2>Department List</h2>
  <?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
			<hr/>
<table class="table">
<thead>
    <tr>
      <th style="width:30%;">#</th>
     
      <th style="width:30%;">Department</th>
     
      <th style="width:30%;">Action</th>
    </tr>
  </thead>
  <tbody>

   <?php 
   $i=0;
  foreach ($getdeptlist as $key => $value) {
   
$i++;
   ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td>
      <?php echo $value->dept_name; ?></td>
      <td>
          <a href="<?php echo base_url(); ?>department/editdepartment/<?php echo $value->dept_id; ?>"><i class="fa fa-pencil"></i></a>
          <a onclick="return confirm('Are you Sure to delete studennt ...!');" href="<?php echo base_url(); ?>department/deldepartment/<?php echo $value->dept_id; ?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
      </td>
    </tr>
    <?php } ?>
  </tbody>
</table>