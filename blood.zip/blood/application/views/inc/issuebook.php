<h2>Add Student</h2>

<?php 

  $smg = $this->session->flashdata('msg');
if (isset($smg)) {
   echo $smg;
}

?>
			<hr/>
			
        <div class="panel-body" style="width:600px;">
            <form action="<?php echo base_url(); ?>manage/addissuebook" method="post">
                <div class="form-group">
                    <label>Student Name</label>
                    <input type="text" name="st_name" class="form-control span12">
                </div>
                <div class="form-group">
                    <label>Department Name</label>
                  <select name="dept_id"  class="form-control span12"> 
                  <option>Select Department Name</option>
                   <?php 
foreach ($departmentlist as $dept) {
   
                  ?>
                   
 <option value="<?php echo $dept->dept_id;?>"><?php echo $dept->dept_name;?> </option>
                         <?php } ?>
                    </select> 
                </div>
                <div class="form-group">
                    <label>Book Name</label>
                  <select name="book_id"  class="form-control span12"> 
                  <option>Select Book Name</option>
                   <?php 
foreach ($booklist as $book) {
   
                  ?>
                   
 <option value="<?php echo $book->book_id;?>"><?php echo $book->book_name;?> </option>
                         <?php } ?>
                    </select> 
                </div>
                <div class="form-group">
                    <label>Author Name</label>
                  <select name="author_id"  class="form-control span12"> 
                  <option>Select Author Name</option>
                   <?php 
foreach ($authorlist as $author) {
   
                  ?>
                   
 <option value="<?php echo $author->author_id;?>"><?php echo $author->author_name;?> </option>
                         <?php } ?>
                    </select> 
                </div>
                <div class="form-group">
				<input type="submit"class="btn btn-primary" value="Submit"> 
                </div>
                   
            </form>
        </div>	
        