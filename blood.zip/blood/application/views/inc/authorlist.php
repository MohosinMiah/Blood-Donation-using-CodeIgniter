  <h2>Autor  List</h2>
  <?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
			<hr/>
<table class="table">
<thead>
    <tr>
      <th style="width:30%;">#</th>
     
      <th style="width:30%;">Author</th>
     
      <th style="width:30%;">Action</th>
    </tr>
  </thead>
  <tbody>

   <?php 
   $i=0;
  foreach ($getdeptlist as $key => $value) {
   
$i++;
   ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td>
      <?php echo $value->author_name; ?></td>
      <td>
          <a href="<?php echo base_url(); ?>author/editauthor/<?php echo $value->author_id; ?>"><i class="fa fa-pencil"></i></a>
          <a onclick="return confirm('Are you Sure to delete studennt ...!');" href="<?php echo base_url(); ?>author/deleteauthor/<?php echo $value->author_id; ?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
      </td>
    </tr>
    <?php } ?>
  </tbody>
</table>