<h2>Update Student Info</h2>
<?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
			<hr/>
			<?php
            if (isset($showstbyid)) {
             
         foreach ($showstbyid as $key => $value) {
            
            ?>
        <div class="panel-body" style="width:600px;">
            <form action="<?php echo base_url(); ?>student/updatastbyid" method="post">
                <div class="form-group">
                    <label>Student Name</label>
                    <input type="hidden" name="st_id" value="<?php echo  $value->st_id; ?>">

                    <input type="text" name="name" value="<?php echo $value->st_name; ?>" class="form-control span12">
                </div>
                <div class="form-group">
                    <label>Department</label>

                     <select name="dept" id="">
                        <?php 
                      

            foreach ($getdeptlist as  $valuee) {
                  ?>
                        <option 
            <?php if ($valuee->dept_id == $value->st_dept){ 
                echo 'selected';
            } ?>

                        value="<?php echo $valuee->dept_id; ?>"><?php echo $valuee->dept_name; ?></option>
                         <?php 
}

                         ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Roll No.</label>
                    <input type="text" name="roll"  value="<?php echo $value->st_roll; ?>" class="form-control span12">
                </div>
				<div class="form-group">
                    <label>Reg. No.</label>
                    <input type="text" name="reg" value="<?php echo $value->st_reg; ?>"  class="form-control span12">
                </div>
               
                <div class="form-group">
				<input type="submit"class="btn btn-primary" value="Submit"> 
                </div>
                   
            </form>
        </div>	
        <?php 
    }     
    }  
             ?>