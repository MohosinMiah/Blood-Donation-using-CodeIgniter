  <h2>Student List</h2>
  <?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
			<hr/>
<table class="table">
<thead>
    <tr>
      <th>#</th>
      <th>Student Name</th>
      <th>Department</th>
      <th>Roll</th>
      <th>Reg.</th>
      <th style="width: 3.5em;">Action</th>
    </tr>
  </thead>
  <tbody>

   <?php 
   $i =0;
   foreach ($getstudentlist as $key => $value) {
    $i++;


   ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $value->st_name; ?></td>
      <td><?php 
                      

            foreach ($getdeptlist as $key => $valuee) {
              if ($valuee->dept_id == $value->st_dept) {
                
             
                  
                         echo $valuee->dept_name; 
}}

                         ?></td>
      <td><?php echo $value->st_roll; ?></td>
      <td><?php echo $value->st_reg; ?></td>
      <td>
          <a href="<?php echo base_url();?>student/editstudent/<?php echo $value->st_id?>"><i class="fa fa-pencil"></i></a>
          <a onclick="return confirm('Are you Sure to delete studennt ...!');" href="<?php echo base_url();?>student/deletestudent/<?php echo $value->st_id?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
      </td>
    </tr>
<?php } ?>
  </tbody>
</table>