<link rel="stylesheet" href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

  <h2>Student List</h2>
  <?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
			<hr/>
<table id="table_id" class="display"><thead>
    <tr>
      <th>#</th>
      <th>Book Name</th>
      <th>Department</th>
      <th>Author</th>
      <th style="width: 3.5em;">Action</th>
    </tr>
  </thead>
  <tbody>

   <?php 
   $i =0;
   foreach ($getbooklist as $key => $value) {
    $i++;


   ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $value->book_name; ?></td>
      <td><?php 
                      

            foreach ($getdeptlist as $dept) {
              if ($dept->dept_id == $value->book_dept) {
                
             
                  
                         echo $dept->dept_name; 
}}

                         ?></td>
<td><?php 
                      

            foreach ($getauthorlist as $key => $auth) {
              if ($auth->author_id == $value->book_author) {
                
             
                  
                         echo $auth->author_name; 
}}

                         ?></td>
      <td>
          <a href="<?php echo base_url();?>book/editbook/<?php echo $value->book_id?>"><i class="fa fa-pencil"></i></a>
          <a onclick="return confirm('Are you Sure to delete studennt ...!');" href="<?php echo base_url();?>book/deletebook/<?php echo $value->book_id?>" role="button" data-toggle="modal"><i class="fa fa-trash-o"></i></a>
      </td>
    </tr>
<?php } ?>
  </tbody>
</table>

<script>
  $(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>