<h2>Add Department</h2>
<?php 

  $smg = $this->session->flashdata('msg');
if (isset($smg)) {
   echo $smg;
}

?><?php echo validation_errors(); ?>
			<hr/>
			
        <div class="panel-body" style="width:600px;">
            <form action="<?php echo base_url(); ?>author/authoradd" method="post">
                <div class="form-group">
                    <label>Author Name</label>
                    <input type="text" name="author" class="form-control span12">
                </div>
               
               
                <div class="form-group">
				<input type="submit"class="btn btn-primary" value="Submit"> 
                </div>
                   
            </form>
        </div>	