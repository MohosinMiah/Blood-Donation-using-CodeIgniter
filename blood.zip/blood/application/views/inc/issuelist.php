  <h2>Student List</h2>
  <?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
			<hr/>
<table class="table">
<thead>
    <tr>
      <th>#</th>
      <th>Student </th>
      <th>Department</th>
      <th>Book</th>
      <th>Author</th>
      <th>Data</th>

      <th style="width: 3.5em;">Action</th>
    </tr>
  </thead>
  <tbody>

   <?php 
   $i =0;
   foreach ($issuelist as $key => $value) {
    $i++;


   ?>
    <tr>
      <td><?php echo $i; ?></td>
      <td><?php echo $value->st_name; ?></td>
<td><?php 


foreach ($departmentlist as $key => $dept) {
if ($dept->dept_id == $value->dept_id) {



echo $dept->dept_name; 
}}

?></td>
<td><?php 


foreach ($booklist as $key => $book) {
if ($book->book_id == $value->book_id) {



echo $book->book_name; 
}}

?></td>      
<td><?php 


foreach ($authorlist as $key => $author) {
if ($author->author_id == $value->author_id) {



echo $author->author_name; 
}}

?></td>      
<td><?php 
$datestring = '%Y-%m- %d - %h:%i %a';
$time = strtotime($value->issue_data);
echo mdate($datestring, $time);
 ?></td>
      <td>
          ff
      </td>
    </tr>
<?php } ?>
  </tbody>
</table>