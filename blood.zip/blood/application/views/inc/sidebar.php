

    <div class="sidebar-nav">
   <ul>
    <li><a href="#" data-target=".dashboard-menu" class="nav-header" data-toggle="collapse"><i class="fa fa-fw fa-dashboard"></i>Dashboard<i class="fa fa-collapse"></i></a>
	</li>
    <li><ul class="dashboard-menu nav nav-list collapse in">
            <li><a href="<?php echo base_url(); ?>student/addstudent.php"><span class="fa fa-caret-right"></span>Add Student </a></li>
            <li><a href="<?php echo base_url();?>student/studentlist.php"><span class="fa fa-caret-right"></span>Student List</a></li>
			
			<li><a href="<?php echo base_url(); ?>department/adddepartment"><span class="fa fa-caret-right"></span>Add Department</a></li>
            <li><a href="<?php echo base_url(); ?>department/departmentlist"><span class="fa fa-caret-right"></span>Department List</a></li>
								
			<li><a href="<?php echo base_url(); ?>author/addauthor"><span class="fa fa-caret-right"></span>Add Author</a></li>
            <li><a href="<?php echo base_url(); ?>author/authorlist"><span class="fa fa-caret-right"></span>Author List</a></li>
			
			<li><a href="<?php echo base_url(); ?>book/addbook"><span class="fa fa-caret-right"></span>Add Book</a></li>
            <li><a href="<?php echo base_url(); ?>book/booklist"><span class="fa fa-caret-right"></span>Book List</a></li>
			
			<li><a href="<?php echo base_url(); ?>manage/issuebook"><span class="fa fa-caret-right"></span>Issue Book</a></li>
            <li><a href="<?php echo base_url(); ?>manage/issuelist""><span class="fa fa-caret-right"></span>Issue List</a></li>			
			
    </ul></li>
  </ul>
	 
    </div>
    <script>
    var options = {
  valueNames: [ 'name', 'born' ],
  // Since there are no elements in the list, this will be used as template.
  item: '<li><h3 class="name"></h3><p class="born"></p></li>'
};

var values = [
  {
    name: 'Jonny Strömberg',
    born: 1986
  },
  {
    name: 'Jonas Arnklint',
    born: 1985
  },
  {
    name: 'Martina Elm',
    born: 1986
  }
];

var userList = new List('example-list', options, values);

userList.add({
  name: 'Gustaf Lindqvist',
  born: 1983
});
</script>

