
<h2>Add Student</h2>
<?php 

  $smg = $this->session->flashdata('msg');
if (isset($smg)) {
   echo $smg;
}

?>
			<hr/>
			
        <div class="panel-body" style="width:600px;">
            <form action="<?php echo base_url(); ?>book/bookadd" method="post">
                <div class="form-group">
                    <label>Book  Name</label>
                    <input type="text" name="name" class="form-control span12">
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select name="dept" id="" class="form-control span12">
                      <option>Slect Department</option>

                        <?php 

            foreach ($getdeptlist as $key => $value) {
                  ?>
                        <option value="<?php echo $value->dept_id; ?>"><?php echo $value->dept_name; ?></option>
                         <?php 
}                                                                                                                                                                                                                         

                         ?>
                    </select>
                </div>
                 <div class="form-group">
                    <label>Author</label>
                    <select name="auth" id="" class="form-control span12">
                    <option>Select Author</option>
                        <?php 
                      

            foreach ($getauthorlist as $key => $valuee) {
                  ?>
                        <option value="<?php echo $valuee->author_id; ?>"><?php echo $valuee->author_name; ?></option>
                         <?php 
}

                         ?>
                    </select>
                </div>
               
                <div class="form-group">
				<input type="submit"class="btn btn-primary" value="Submit"> 
                </div>
                   
            </form>
        </div>	
         