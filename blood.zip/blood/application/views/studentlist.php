<?php 
if (isset($header)) {echo $header;}
?>
<?php 
if (isset($sidebar)) {echo $sidebar;}
?>
    <div class="content">
        <div class="main-content">

       <?php 
if (isset($studentlist)) {echo $studentlist;}
?>
<div style="clear:both;"/>

        </div>

    </div>
    </div>
	<?php 
if (isset($footer)) {echo $footer;}
?>