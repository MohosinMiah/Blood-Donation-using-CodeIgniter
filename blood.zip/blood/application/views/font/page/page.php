 <?php 
   foreach ($singlepage as  $page) {
    
 ?>

      <div class="container">
        <h3 class="text-center" style="padding: 30px;color: green;"><?php echo $page->title; ?></h3>
       <?php echo $page->body; ?> 
      </div>

      <br>
      <?php } ?>
