<?php  if (isset($header)) { echo $header; } ?>
<?php  if (isset($slider)) { echo $slider; } ?>
<?php  if (isset($main)) { echo $main; } ?>
<?php  if (isset($footer)) { echo $footer; } ?>
  
   
