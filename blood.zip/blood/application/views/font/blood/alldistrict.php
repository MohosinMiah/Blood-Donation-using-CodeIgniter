 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
<!--content-->
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<br>
<center><h2 style="color: green;padding-bottom:40px;">ALl District Donors</h2></center>

 <div class="container" style="background-color: threedface;
    padding: 20px;;">
  <?php 
  foreach ($districtall as  $alldis) {
  ?>
<div class="col-sm-3">
  <ul class="nav nav-pills" role="tablist">
    <?php 
        $id = $alldis->districtid;
        $numdonors = $this->user_model->getdiname($id);
    ?>
  <li role="presentation"><a href="<?php echo base_url();?>blood/district/<?php  echo $alldis->name;?>/<?php  echo $alldis->districtid;?>"><?php echo $alldis->name;?> ( <?php echo $numdonors; ?> )</a></li>
</ul>
</div>
<?php } ?>

  </div>

 
<br>
<br>
<script>  $(document).ready(function(){
   $('#example').dataTable( {
  
   "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
} );

 $('[data-toggle="tooltip"]').tooltip();   
});

</script>
