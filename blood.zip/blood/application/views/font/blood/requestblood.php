 <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

<!-- HTML Form (wrapped in a .bootstrap-iso div) -->

 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<style>   
.panel-default {
     background-color: #fafafa;
    border-color: #fafafa;
    box-shadow: 1px 1px 1px 1px;
}       
.col-sm-5 {
    /*height: 45px;*/
}

    input.hidden {
    position: absolute;
    left: -9999px;
}
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 20px;
  background: #fff;
  min-height: 460px;
}
#profile-image1 {
    cursor: pointer;
  
     width: 100px;
    height: 100px;
	border:2px solid #03b1ce ;}
	.tital{ font-size:16px; font-weight:500;}
	 .bot-border{ border-bottom:1px #f8f8f8 solid;  margin:5px 0  5px 0}	</style>
<!-- Carousel
    ================================================== -->
<div class="container">
 
  
						

  <div class="col-md-12">
<div class="panel panel-default">
  <div class="panel-heading">  <h4 style="color: green;">Request For Blood</h4></div>
   <div class="panel-body">
       
<?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
    <div class="box box-info">
        <form action="<?php echo base_url();?>user/request" method="post" enctype="multipart/form-data">
          

           
<div class="col-sm-5 col-xs-6 tital " >Your Name*:</div><div class="col-sm-7 col-xs-6 "> <input type="text" name="name" class="form-control" > </div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Blood Group*:</div><div class="col-sm-7">


<select name="bgroup" class="form-control" >

  <option>Select Blood Group</option>
  <?php 
     foreach ($group as $bg) { 
?>
  <option value="<?php echo $bg->bloodid; ?>" 
  ><?php echo $bg->group; ?></option>
<?php 
}
?>
</select>


 </div>



  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Contact No*:</div><div class="col-sm-7"> <input type="text" class="form-control"  name="contact" > </div>


 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Amount(Unit/Bag)*:</div><div class="col-sm-7"> <input type="number"  name="amount" > </div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Date of Donation*:</div><div class="col-sm-7">

 <div class="input-group">
        <div class="input-group-addon">
         <i class="fa fa-calendar">
         </i>
        </div>
        <input class="form-control" id="date" name="date"  type="text"/>
       </div>
      
  </div>




 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Living District*:</div><div class="col-sm-7">

<select name="lidistrict" class="form-control" >

  <option>Select District:</option>
  <?php 
     foreach ($alldist as $dis) { 
?>
  <option value="<?php echo $dis->districtid; ?>" 
  ><?php echo $dis->name; ?></option>
<?php 
}
?>
</select>

     
</div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Present Address Location*:</div><div class="col-sm-7">  <textarea name="paddress" id="" cols="40" rows="2" ></textarea>
  <p>Ex. Dhaka , Uttara , Sector-10 , Road-7 , House No -11</p>

</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Message:</div><div class="col-sm-7">  <textarea name="about" id="" cols="40" rows="3"></textarea>
</div>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " ></div><div class="col-sm-7"><input type="submit"  value="Send"></div>



        </form>
     
    
       
       
       
       
       
       
       
       
   
   </div>
   </div>
   </div>
</div>




         </div>

</div>
</div>

   <!-- /.carousel -->

<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
  $(document).ready(function(){
    var date_input=$('input[name="date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'mm/dd/yyyy',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  })
</script>