 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
<!--content-->
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<br>

<div class="container">
 <div class="spec ">
				<h3 style="color: green;">All Request For Blood</h3>
				<div class="ser-t">
					<b></b>
					<span><i></i></span>
					<b class="line"></b>
				</div>
			</div>
  <div class="row">
    <div class="col-md-12"> 

<table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Name</th>
        <th>Blood Group</th>
        <th>Contact</th>
        <th>Amount</th>
        <th>date of Donation</th>
        <th>District</th>
        <th>Address</th>
        <th>Message</th>
						</tr>
					</thead>
					<tbody>
                   </tr>   
<?php 
foreach ($allrequest as  $reqat) {
?>
      <tr class="active">
        <td><?php echo $reqat->name; ?></td>
        <td>
          <?php 
     foreach ($group as $bg) { if($reqat->bgroup == $bg->bloodid){ echo $bg->group; } }
?>
        </td>
        <td><?php echo $reqat->contact; ?></td>
        <td><?php echo $reqat->amount; ?> (Bag)</td>
        <td><?php echo $reqat->date; ?></td>
        <td><?php foreach ($districtall as $dis) { if($reqat->lidistrict == $dis->districtid){ echo $dis->name; } }
?></td>
        <td><?php echo $reqat->paddress; ?></td>
        <td><?php echo $reqat->about; ?></td>
      </tr>
<?php } ?>
              </tbody>
          </table>


  </div>
</div>
<script>  $(document).ready(function(){
   $('#example').dataTable( {
  "pageLength": 20,
    buttons: [
        {
            extend: 'pdf',
            text: 'Save current page',
            exportOptions: {
                modifier: {
                    page: 'current'
                }
            }
        }
    ],
   "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
} );
});</script>
