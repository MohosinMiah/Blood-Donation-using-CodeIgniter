 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
<!--content-->
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<br>
<center><h2 style="color: green;">

<?php 
foreach ($onedis as  $donor) {
  
foreach ($districtall as $dis) { if($donor->lidistrict == $dis->districtid){ echo $dis->name; } }}
?>
 Blood Donor List</h2></center>
<?php 
  if (isset($msg)) {
echo $this->session->flashdata('msg');
  }
?>
<div class="container" style="padding-left: 15px;padding-right: 10px;">
  <?php 
if (isset($alldonar)) {
  
  ?>
	<table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Name</th>
							<th>Blood Group</th>
							<th>Living District</th>
							<th>Gender</th>
							<th>Contact</th>
							<th>Donor Status</th>
							<th>Num. Donates</th>
							<th>Email</th>
							<th>Profile</th>
						</tr>
					</thead>
					<tbody>
						<?php 
foreach ($alldonar as  $donor) {
						?>
						<tr>
							<td><?php echo $donor->name;?></td>
							<td>
								<?php 
     foreach ($group as $bg) { if($donor->bgroup == $bg->bloodid){ echo $bg->group; } }
?>
							</td>
							<td>
<?php foreach ($districtall as $dis) { if($donor->lidistrict == $dis->districtid){ echo $dis->name; } }
?>

							</td>
							<td class="center"><?php if($donor->gender == 3){echo "Male";} ?>  
  <?php if($donor->gender == 4){echo "Female";} ?>  
  <?php if($donor->gender == 0){echo "Undefined";} ?>  </td>
							<td><?php echo $donor->contact; ?></td>
							<td><?php 
if($donor->status == 3){ ?>
<img src="<?php echo base_url(); ?>images/agree.png"  data-toggle="tooltip" title ="<?php echo $donor->name; ?> Interested to Donate His Blood" alt="Agree">
<?php 
}elseif ($donor->status == 4) {  ?>
<img src="<?php echo base_url(); ?>images/notinterested.png" data-toggle="tooltip" title ="<?php echo $donor->name; ?> Not-Interested to Donate His Blood" alt="Not-Interested">
<?php }else{  ?>
<img src="<?php echo base_url(); ?>images/notready.png" data-toggle="tooltip" title ="<?php echo $donor->name; ?> Not Ready to Donate His Blood" alt="Not Ready">
<?php
}
?></td>
							<td ><button type="button"><span class="badge"><?php 
							$usid = $donor->userid;
							$this->user_model->hitosyid($usid);
                        echo $this->session->userdata('tohistoryid');
							 ?></span> </button> </td>

							<td><a href="<?php echo base_url();?>donor/viewprofile/<?php echo $donor->userid;?>" target="_blank" class="btn btn-success">Profile</a></td>
							<td>
								<div class="panel-footer">
                        <a data-original-title="Broadcast Message" data-toggle="tooltip" type="button" class="btn btn-sm btn-primary">
<!--Button trigger for modal--> 
<button type="button" class="btn btn-success" style=" background: green;" data-toggle="modal" data-target="#myModal"><i class="glyphicon glyphicon-envelope"></i> Contact</button>
 
<!--Begin Modal Window--> 
<div class="modal fade left" id="myModal"> 
<div class="modal-dialog"> 
<div class="modal-content"> 
<div class="modal-header"> 
<h3 class="no-margin">Contact Form</h3>
<button type="button" class="close" data-dismiss="modal" title="Close"><span class="glyphicon glyphicon-remove"></span>
</button> 
</div> 
<div class="modal-body">

<!--NOTE: you will need to provide your own form processing script--> 
<small> <b style="color: red;">All Field are Required</b></small></p>

<form class="form-horizontal" role="form" method="post" action="<?php echo base_url();?>user/sendmessage"> 
<span class="required">* Required</span> 
<div class="form-group"> 
<label for="name" class="col-sm-3 control-label">
<span class="required">*</span> Name:</label> 
<div class="col-sm-9"> 
<input type="text" class="form-control" id="name" name="name" placeholder="Enter Your Name " required> 
<input type="hidden" name="userid" value="$donor->userid">
</div> 
</div> 
<div class="form-group"> 
<label for="name" class="col-sm-3 control-label">
<span class="required">*</span> Contact Number:</label> 
<div class="col-sm-9"> 
<input type="phone" class="form-control" id="contact" name="mobile" placeholder="Enter Your Mobile Number" required> 
</div> 
</div> 
<div class="form-group"> 
<label for="name" class="col-sm-3 control-label">
<span class="required">*</span> Email:</label> 
<div class="col-sm-9"> 
<input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email Address" required> 
</div> 
</div> 
<div class="form-group"> 
<label for="email" class="col-sm-3 control-label">
<span class="required">*</span> Subject: </label> 
<div class="col-sm-9"> 
<input type="email" class="form-control" id="email" name="subject" value="I need Blood . Please help <?php echo $donor->name; ?>" placeholder="Subject" readonly required> 
</div> 
</div> 
<div class="form-group"> 
<label for="message" class="col-sm-3 control-label">
<span class="required">*</span> Message:</label> 
<div class="col-sm-9"> 
<textarea name="message" rows="4" required class="form-control" id="message" placeholder="Message "></textarea> 
</div> 
</div> 

<div class="form-group"> 
<div class="col-sm-offset-3 col-sm-6 col-sm-offset-3"> 
<button type="submit" id="submit" name="submit" class="btn-lg btn-primary">SUBMIT</button> 
</div> 
</div> 
<!--end Form--></form>
</div>
<div class="modal-footer"> 
<div class="col-xs-10 pull-left text-left text-muted"> 
<small><strong></strong>
</small> 
</div> 
<button class="btn-sm close" type="button" data-dismiss="modal">Close</button> 
</div> 
</div> 
</div> 
</div>


                        </a>
                        <span class="pull-right">
<!--                             <a href="edit.html" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                            <a data-original-title="Remove this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
 -->                        </span>
                    </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       

							</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
</div>
<?php }?>
<div class="container">
 <div class="spec ">
				<h3 style="color: green;">Recent Request For Blood</h3>
				<div class="ser-t">
					<b></b>
					<span><i></i></span>
					<b class="line"></b>
				</div>
			</div>
  <div class="row">
    <div class="col-md-12"> <table class="table" style="font-size: 16px;">
    
    <tbody>
      <tr class="success">
        <th>Name</th>
        <th>Blood Group</th>
        <th>Contact</th>
        <th>Amount</th>
        <th>date of Donation</th>
        <th>District</th>
        <th>Address</th>
        <th>Message</th>
       
      </tr>   
<?php 
foreach ($limitrequest as $key => $reqat) {
?>
      <tr class="active">
        <td><?php echo $reqat->name; ?></td>
        <td>
          <?php 
     foreach ($group as $bg) { if($reqat->bgroup == $bg->bloodid){ echo $bg->group; } }
?>

          
        </td>
        <td><?php echo $reqat->contact; ?></td>
        <td><?php echo $reqat->amount; ?> (Bag)</td>
        <td><?php echo $reqat->date; ?></td>
        <td>
          <?php foreach ($districtall as $dis) { if($reqat->lidistrict == $dis->districtid){ echo $dis->name; } }
?>
        </td>
        <td><?php echo $reqat->paddress; ?></td>
        <td><?php echo $reqat->about; ?></td>
      </tr>
<?php } ?>
      
    </tbody>
  </table></div>
    
  </div>

<div class="container">
  <center><h2 style="color: green;padding:20px;">Donor Status Meaning</h2></center>
  <table class="table" style="font-size: 17px;">
    <thead>
      <tr>
        <th><img src="<?php echo base_url(); ?>images/agree.png" data-toggle="tooltip" title="Interested" ></th>
        <th><img src="<?php echo base_url(); ?>images/notinterested.png" data-toggle="tooltip" title="Not-Interested" ></th>
        <th><img src="<?php echo base_url(); ?>images/notready.png" data-toggle="tooltip" title="Not-Ready" ></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Interested</td>
        <td>Not-Interested</td>
        <td>Not-Ready</td>
      </tr>   
  </tbody>
</table>

</div>
   

<script>  $(document).ready(function(){
   $('#example').dataTable( {
  
   "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
} );

 $('[data-toggle="tooltip"]').tooltip();   
});

</script>
