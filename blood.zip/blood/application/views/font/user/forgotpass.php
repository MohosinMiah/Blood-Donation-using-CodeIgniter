<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Forgot password</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/stylelogin.css" media="screen" />
</head>
<body>
	<p><?php 
$ermsg = $this->session->flashdata('msg');
if (isset($ermsg)) {
	echo $ermsg;
}

?></p>
<div class="container">
	<section id="content">
		<form action="<?php echo base_url();?>donor/sendpassword" method="post">
			<h1>Enter Your Email </h1>

			<div>
				<input type="text" placeholder="Email " required="" name="email"/>
			</div>
			
			<div>
				<input type="submit" value="Get_password" />
			

			</div>
		</form><!-- form -->
		<div class="button">
			<a href="<?php echo base_url();?>">Blood Donation Club</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>