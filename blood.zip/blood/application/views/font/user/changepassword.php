<?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<div class="container">
 
  <div class="col-md-4">
    
        <h4 style="color: green;">Update Your Profile</h4>
        
        <div class="profile-usermenu">
          <ul class="nav">

            <br>
            <li>
              <a href="<?php echo base_url(); ?>donor/editprofile">
              <i class="glyphicon glyphicon-user"></i>
              Edit Profile </a>
            </li>
            <br>

            <li>
              <a href="<?php echo base_url();?>donor/changepassword" >
              <i class="fa fa-key"></i>
              Change Password </a>
            </li>
            <br>

            <li>
              <a href="<?php echo base_url(); ?>donor/add_donationm">
              <i class="glyphicon glyphicon-edit"></i>
              Add a Donation </a>
            </li>
              <br>
            <li>
              <a href="#">
              <i class="fa fa-history"></i>
              Donation History </a>
            </li>
          </ul>
        </div>
        <!-- END MENU -->
      

  </div>

  <div class="col-md-8">
<div class="panel panel-default">
  <div class="panel-heading">  <h4 >Change Password</h4></div>
   <div class="panel-body">

    <div class="box box-info">
        <form action="<?php echo base_url();?>user/changedonorpass" method="post" >
       

    <div class="box box-info">
          
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital " >Old Password:</div><div class="col-sm-7 col-xs-6 "> <input type="password" name="password" class="form-control" > </div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >New Password:</div><div class="col-sm-7"><input type="password" name="upassword" class="form-control" ></div>



  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " ></div><div class="col-sm-7"><input type="submit"  value="Update" ></div>



        </form>
     
    
       
       
       
       
       
       
       
       
   
   </div>
   </div>
   </div>
</div>




         </div>

</div>
</div>

   