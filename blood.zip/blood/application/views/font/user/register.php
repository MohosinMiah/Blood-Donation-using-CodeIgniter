 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<!--login-->
<?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>

	<div class="login">
		<div class="main-agileits">
				<div class="form-w3agile form1">
					<h3>Register</h3>
						<form class="" method="post" action="<?php echo base_url(); ?>donor/registerdoner">
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Your Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user fa" aria-hidden="true"></i></span>
									<input type="text" class="form-control" name="name"   placeholder="Enter your Name" required="" />
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Your Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
									<input type="email" class="form-control" name="email"   placeholder="Enter your Email" required="" />
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Blood Group</label>
							<div class="cols-sm-10">
								<select name="bgroup"  class="form-control span12">
									<?php 
                            foreach ($group as  $bg) {
                            	
									?>
									<option value="<?php echo $bg->bloodid; ?>" ><?php echo $bg->group; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>


						<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">Living District</label>
							<div class="cols-sm-10">
								<select name="lidistrict"  class="form-control span12">

		<?php 
foreach ($districtall as  $district) { ?>							
<option value="<?php echo $district->districtid; ?>" ><?php echo $district->name; ?></option>
<?php } ?>
								</select>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
									<input type="password" class="form-control" name="password"   placeholder="Enter your Password"/>
								</div>
							</div>
						</div>

						

						<div class="form-group ">
							<input  type="submit" value="Register"  ></input>
						</div>
						
					</form>
				</div>
				
			</div>
		</div>