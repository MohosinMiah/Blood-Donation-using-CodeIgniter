 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<style>   


    input.hidden {
    position: absolute;
    left: -9999px;
}
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 20px;
  background: #fff;
  min-height: 460px;
}
#profile-image1 {
    cursor: pointer;
  
     width: 100px;
    height: 100px;
	border:2px solid #03b1ce ;
}
	.tital{ 
    font-size:16px; font-weight:500;
  }
	 .bot-border{ border-bottom:1px #f8f8f8 solid;  margin:5px 0  5px 0}	</style>
<!-- Carousel
    ================================================== -->
<div class="container">
 


  <div class="col-md-12">
<div class="panel panel-default">
  <div class="panel-heading">  <h4 >Donor Profile</h4></div>
   <div class="panel-body">
       <?php 
       foreach ($donorinfo as $key => $donor) { ?>

    <div class="box box-info">
        
            <div class="box-body">
                     <div class="col-sm-6">
                     <div  align="center"> <img alt="User Pic" src="<?php if(empty($donor->image)){  echo "https://x1.xingassets.com/assets/frontend_minified/img/users/nobody_m.original.jpg";}else{ echo $donor->image; } ?> " id="profile-image1" class="img-circle img-responsive"> 
                
               
                <!--Upload Image Js And Css-->
           
                     </div>
              
              <br>
    
              <!-- /input-group -->
            </div>
            <div class="col-sm-6">
            <h4 style="color:#00b1b1;"> Welcome <?php $donorname = $this->session->userdata('name'); if(isset($donorname)) {echo $donorname;}?></h4></span>
              <span><p>We Are Proud as a Blood Donor</p></span>            
            </div>
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital " >Donor Name:</div><div class="col-sm-7 col-xs-6 "><?php echo $donor->name; ?></div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Blood Group:</div><div class="col-sm-7">
<?php 
     foreach ($group as $bg) { if($donor->bgroup == $bg->bloodid){ echo $bg->group; } }
?>
   
 </div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Number of Donat:</div><div class="col-sm-7">  

<?php 
              $usid = $donor->userid;
              $this->user_model->hitosyid($usid);
                        echo $this->session->userdata('tohistoryid');
               ?>
</div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Status:</div><div class="col-sm-7"> <?php 
if($donor->status == 3){ ?>
<img src="<?php echo base_url(); ?>images/agree.png" title ="<?php echo $donor->name; ?> Interested to Donate His Blood" alt="Agree">
<?php 
}elseif ($donor->status == 4) {  ?>
<img src="<?php echo base_url(); ?>images/notinterested.png" alt=""> 
<?php }else{  ?>
<img src="<?php echo base_url(); ?>images/notready.png" alt="">
<?php
}
?></div>


  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Contact No:</div><div class="col-sm-7"><?php if(!empty($donor->contact)){ echo $donor->contact;}else{echo "N/A"; } ?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Receive Message:</div><div class="col-sm-7"> <input type="checkbox" name="amessage" value="2"  <?php if($donor->amessage == 3){ echo "checked"; } ?> > (<small style="color: red;">Allow to receive message</small>) </div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Smoker(?):</div><div class="col-sm-7">
  <?php 
if($donor->smoker == 2){ 
echo "Smoker";
}elseif ($donor->smoker == 3) {  
echo "Non-Smoker";
 }else{  
echo "Undefined";
}
?>
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Drug Accidted(?):</div><div class="col-sm-7">
<?php 
if($donor->drug == 2){ 
echo "Addicted";
}elseif ($donor->drug == 3) {  
echo "Non-Addicted";
 }else{  
echo "Undefined";
}
?>
</div>
 
 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Last Donate:</div><div class="col-sm-7">
  <?php 
      foreach ($lastdonate as  $ld) {
        echo $ld->date;
    
}
  ?>

</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Gender:</div><div class="col-sm-7">
  <?php if($donor->gender == 3){echo "Male";} ?>  
  <?php if($donor->gender == 4){echo "Female";} ?>  
  <?php if($donor->gender == 0){echo "Undefined";} ?>  
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Weight:</div><div class="col-sm-7"><?php if(!empty($donor->weight) && $donor->weight !== "0.00" ){ echo $donor->weight;}else{echo "N/A"; } ?> KG</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Date of Birth:</div><div class="col-sm-7"><?php if(!empty($donor->bdate)){ echo $donor->bdate;}else{echo "N/A"; } ?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Living District:</div><div class="col-sm-7">
<?php foreach ($districtall as $dis) { if($donor->lidistrict == $dis->districtid){ echo $dis->name; } }
?>
     
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Home District:</div><div class="col-sm-7">
<?php 
     foreach ($districtall as $dis) { if($donor->homdistrict == $dis->districtid){ echo $dis->name; } }
?>  
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Natonality:</div><div class="col-sm-7"><?php 
     foreach ($country as $coun) { if($donor->hcountry == $coun->id){ echo $coun->name; } }
?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Facebook ID:</div><div class="col-sm-7"><?php if(!empty($donor->website)){ echo $donor->website;}else{echo "N/A"; } ?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Present Address:</div><div class="col-sm-7"><?php if(!empty($donor->paddress)){ echo $donor->paddress;}else{echo "N/A"; } ?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >About:</div><div class="col-sm-7"><?php if(!empty($donor->about)){ echo $donor->about;}else{echo "N/A"; } ?></div>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
<?php } ?>
 <div class="panel-footer">
                        <a data-original-title="Broadcast Message" data-toggle="tooltip" type="button" class="btn btn-sm btn-primary">
<!--Button trigger for modal--> 
<button type="button" class="btn btn-primary" style=" background: green;" data-toggle="modal" data-target="#myModal"><i class="glyphicon glyphicon-envelope"></i> Contact</button>
 
<!--Begin Modal Window--> 
<div class="modal fade left" id="myModal"> 
<div class="modal-dialog"> 
<div class="modal-content"> 
<div class="modal-header"> 
<h3 class="no-margin">Contact Form</h3>
<button type="button" class="close" data-dismiss="modal" title="Close"><span class="glyphicon glyphicon-remove"></span>
</button> 
</div> 
<div class="modal-body">

<!--NOTE: you will need to provide your own form processing script--> 
<small> <b style="color: red;">All Field are Required</b></small></p>

<form class="form-horizontal" role="form" method="post" action="<?php echo base_url();?>user/sendmessage"> 
<span class="required">* Required</span> 
<div class="form-group"> 
<label for="name" class="col-sm-3 control-label">
<span class="required">*</span> Name:</label> 
<div class="col-sm-9"> 
<input type="text" class="form-control" id="name" name="name" placeholder="Enter Your Name " required> 
<input type="hidden" name="userid" value="$donor->userid">
</div> 
</div> 
<div class="form-group"> 
<label for="name" class="col-sm-3 control-label">
<span class="required">*</span> Contact Number:</label> 
<div class="col-sm-9"> 
<input type="phone" class="form-control" id="contact" name="mobile" placeholder="Enter Your Mobile Number" required> 
</div> 
</div> 
<div class="form-group"> 
<label for="name" class="col-sm-3 control-label">
<span class="required">*</span> Email:</label> 
<div class="col-sm-9"> 
<input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email Address" required> 
</div> 
</div> 
<div class="form-group"> 
<label for="email" class="col-sm-3 control-label">
<span class="required">*</span> Subject: </label> 
<div class="col-sm-9"> 
<input type="email" class="form-control" id="email" name="subject" value="I need Blood . Please help <?php echo  $this->session->userdata('name'); ?>" placeholder="Subject" readonly required> 
</div> 
</div> 
<div class="form-group"> 
<label for="message" class="col-sm-3 control-label">
<span class="required">*</span> Message:</label> 
<div class="col-sm-9"> 
<textarea name="message" rows="4" required class="form-control" id="message" placeholder="Message "></textarea> 
</div> 
</div> 

<div class="form-group"> 
<div class="col-sm-offset-3 col-sm-6 col-sm-offset-3"> 
<button type="submit" id="submit" name="submit" class="btn-lg btn-primary">SUBMIT</button> 
</div> 
</div> 
<!--end Form--></form>
</div>
<div class="modal-footer"> 
<div class="col-xs-10 pull-left text-left text-muted"> 
<small><strong></strong>
</small> 
</div> 
<button class="btn-sm close" type="button" data-dismiss="modal">Close</button> 
</div> 
</div> 
</div> 
</div>


                        </a>
                        <span class="pull-right">
<!--                             <a href="edit.html" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning"><i class="glyphicon glyphicon-edit"></i></a>
                            <a data-original-title="Remove this user" data-toggle="tooltip" type="button" class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-remove"></i></a>
 -->                        </span>
                    </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
       

              
       
            
     
    <script>
              $(function() {
    $('#profile-image1').on('click', function() {
        $('#profile-image-upload').click();
    });
});       
              </script> 
       
       
       
       
       
       
       
       
       
   </div>
</div>




         </div>

</div>

   <!-- /.carousel -->