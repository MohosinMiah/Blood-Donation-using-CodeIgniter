<?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<div class="container">
 
  <div class="col-md-4">
    
        <h4 style="color: green;">Update Your Profile</h4>
        
        <div class="profile-usermenu">
          <ul class="nav">

            <br>
            <li>
              <a href="<?php echo base_url(); ?>donor/editprofile">
              <i class="glyphicon glyphicon-user"></i>
              Edit Profile </a>
            </li>
            <br>

            <li>
              <a href="<?php echo base_url();?>donor/changepassword" >
              <i class="fa fa-key"></i>
              Change Password </a>
            </li>
            <br>

            <li>
              <a href="<?php echo base_url(); ?>donor/add_donationm">
              <i class="glyphicon glyphicon-edit"></i>
              Add a Donation </a>
            </li>
              <br>
            <li>
              <a href="<?php echo base_url(); ?>donor/history">
              <i class="fa fa-history"></i>
              Donation History </a>
            </li>
          </ul>
        </div>
        <!-- END MENU -->
      

  </div>

  <div class="col-md-8">
<div class="panel panel-default">
  <div class="panel-heading">  <h4 >Add Donation History</h4></div>
   <div class="panel-body">

    <div class="box box-info">
        <form action="<?php echo base_url();?>user/adddonation" method="post" >
       

    <div class="box box-info">
          
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
<div class="col-sm-5 col-xs-6 tital " >Date of Donation*:</div><div class="col-sm-7">
<div class="input-group">
        <div class="input-group-addon">
        <i class="fa fa-calendar">
        </i>
        </div>
        <input class="form-control" id="date" name="date"  type="text"/>
        </div>
</div>


              
<div class="col-sm-5 col-xs-6 tital " >Donated To*:</div><div class="col-sm-7 col-xs-6 "> 
<select name="status">
  <option>Select One</option>
  <option value="2">Direct To Patient</option>
  <option value="3">To a Blood Bank</option>
</select>
 </div>
     <div class="clearfix"></div>
<div class="bot-border"></div>
<br>
 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Recipient Address*:</div><div class="col-sm-7"> <textarea name="receptaddress" id="" cols="30" rows="5" ></textarea>
<p>Ex:Uttara,Dhaka</p> </div>


  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " ></div><div class="col-sm-7"><input type="submit"  value="Add" ></div>



        </form>
     
    
       
       
       
       
       
       
       
       
   
   </div>
   </div>
   </div>
</div>




         </div>

</div>
</div>

   
<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
  $(document).ready(function(){
    var date_input=$('input[name="date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'mm/dd/yyyy',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  })
</script>