 <!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>

<!-- HTML Form (wrapped in a .bootstrap-iso div) -->

 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<style>   
.panel-default {
     background-color: #fafafa;
    border-color: #fafafa;
    box-shadow: 1px 1px 1px 1px;
}       
.col-sm-5 {
    /*height: 45px;*/
}

    input.hidden {
    position: absolute;
    left: -9999px;
}
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 20px;
  background: #fff;
  min-height: 460px;
}
#profile-image1 {
    cursor: pointer;
  
     width: 100px;
    height: 100px;
	border:2px solid #03b1ce ;}
	.tital{ font-size:16px; font-weight:500;}
	 .bot-border{ border-bottom:1px #f8f8f8 solid;  margin:5px 0  5px 0}	</style>
<!-- Carousel
    ================================================== -->
<div class="container">
 
  <div class="col-md-4">
  	
				<!-- SIDEBAR USERPIC -->
				<div class="profile-userpic">
					<img src="http://keenthemes.com/preview/metronic/theme/assets/admin/pages/media/profile/profile_user.jpg" class="img-responsive" alt="">
				</div>
				<!-- END SIDEBAR USERPIC -->

				<!-- END SIDEBAR USER TITLE -->
				
				<!-- SIDEBAR MENU -->
				<h4 style="color: green;">Update Your Profile</h4>
        <?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
				<div class="profile-usermenu">
					<ul class="nav">

						<br>
						<li>
							<a href="<?php echo base_url(); ?>donor/editprofile">
							<i class="glyphicon glyphicon-user"></i>
							Edit Profile </a>
						</li>
						<br>

						<li>
							<a href="<?php echo base_url();?>donor/changepassword" >
              <i class="fa fa-key"></i>
              Change Password </a>
						</li>
						<br>

						<li>
              <a href="<?php echo base_url(); ?>donor/add_donationm">
              <i class="glyphicon glyphicon-edit"></i>
              Add a Donation </a>
            </li>
              <br>
            <li>
              <a href="<?php echo base_url(); ?>donor/history">
              <i class="fa fa-history"></i>
              Donation History </a>
            </li>
					</ul>
				</div>
				<!-- END MENU -->
			

  </div>

  <div class="col-md-8">
<div class="panel panel-default">
  <div class="panel-heading">  <h4 >Donor Profile</h4></div>
   <div class="panel-body">
       <?php 
       foreach ($donorinfo as $key => $donar) { ?>

    <div class="box box-info">
        <form action="<?php echo base_url();?>donor/updateinfo" method="post" enctype="multipart/form-data">
          

            <div class="box-body">
                     <div class="col-sm-6">
                     <div  align="center"> <img alt="User Pic" src="<?php if(empty($donar->image)){  echo "https://x1.xingassets.com/assets/frontend_minified/img/users/nobody_m.original.jpg";}else{ echo $donar->image; } ?> " id="profile-image1" class="img-circle img-responsive"> 
                
                <input   type="file" name="image">
<div style="color:#999;" >upload profile image</div>
                <!--Upload Image Js And Css-->
           
                     </div>
              
              <br>
    
              <!-- /input-group -->
            </div>
            <div class="col-sm-6">
            <h4 style="color:#00b1b1;"> Welcome <?php $donarname = $this->session->userdata('name'); if(isset($donarname)) {echo $donarname;}?></h4></span>
              <span><p>We Are Proud as a Blood Donor</p></span>            
            </div>
            <div class="clearfix"></div>
            <hr style="margin:5px 0 5px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital " >Donor Name:</div><div class="col-sm-7 col-xs-6 "> <input type="text" name="name" class="form-control" value="<?php echo $donar->name; ?>"> </div>
     <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Blood Group:</div><div class="col-sm-7">


<select name="bgroup" class="form-control" >

  <?php 
     foreach ($group as $bg) { 
?>
  <option value="<?php echo $bg->bloodid; ?>" <?php 
if($donar->bgroup == $bg->bloodid){ echo "selected"; }
?>
  ><?php echo $bg->group; ?></option>
<?php 
}
?>
</select>


 </div>
  <div class="clearfix"></div>
<div class="bot-border"></div>


<div class="col-sm-5 col-xs-6 tital " >Status:</div><div class="col-sm-7"> 
<input type="radio" name="status" value="3" <?php if($donar->status == 3){echo "checked";} ?> > <img src="<?php echo base_url(); ?>images/agree.png" title ="<?php echo $donar->name; ?> Interested to Donate His Blood" alt="Agree">
<input type="radio" name="status" value="4" <?php if($donar->status == 4){echo "checked";} ?>> <img src="<?php echo base_url(); ?>images/notinterested.png" title ="<?php echo $donar->name; ?> Not-Interested to Donate His Blood" alt="Agree">
<input type="radio" name="status"  value="5" <?php if($donar->status == 5){echo "checked";} ?> > <img src="<?php echo base_url(); ?>images/notready.png" title ="<?php echo $donar->name; ?> Do not Ready to Donate His Blood" alt="Agree">
</div>


  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Contact No:</div><div class="col-sm-7"> <input type="text" class="form-control"  name="contact" value="<?php if(!empty($donar->contact)){ echo $donar->contact;}else{echo "N/A"; } ?>"> </div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Receive Message:</div><div class="col-sm-7"> 
<input type="radio" name="amessage" value="3"  <?php if($donar->amessage == 3){ echo "checked"; } ?> > Allow (<small style="color: red;">Allow to receive message</small>) 
<input type="radio" name="amessage" value="2"  <?php if($donar->amessage == 2){ echo "checked"; } ?> > Not-Allow (<small style="color: red;">Not-Allow to receive message</small>)
 </div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Smoker(?):</div><div class="col-sm-7">
  
<input type="radio" name="smoker" value="3" <?php if($donar->smoker == 3){echo "checked";} ?> > Smoker

<input type="radio" name="smoker" value="4" <?php if($donar->smoker == 4){echo "checked";} ?>> Non-Smoker

<input type="radio" name="smoker" value="0" <?php if($donar->smoker == 0){echo "checked";} ?>> Undefined

</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Drug Accidted(?):</div><div class="col-sm-7">

<input type="radio" name="drug" value="2" <?php if($donar->drug == 2){echo "checked";} ?> > Addicted

<input type="radio" name="drug" value="3" <?php if($donar->drug == 3){echo "checked";} ?>> Non-Addicted

<input type="radio" name="drug" value="0" <?php if($donar->drug == 0){echo "checked";} ?>> Undefined

</div>
 
 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Last Donate:</div><div class="col-sm-7">Indian</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Gender:</div><div class="col-sm-7">
  
 <input type="radio" name="gender" value="3" <?php if($donar->gender == 3){echo "checked";} ?> > Male 
 <input type="radio" name="gender"  value="4" <?php if($donar->gender == 4){echo "checked";} ?>> Female 
 <input type="radio" name="gender"  value="0"  <?php if($donar->gender == 0){echo "checked";} ?> > Undefined 
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Weight:</div><div class="col-sm-7"> <input type="number"  name="weight" value="<?php if(!empty($donar->weight) && $donar->weight !== "0.00" ){ echo $donar->weight;}else{echo "N/A"; } ?>"> KG</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Date of Birth:</div><div class="col-sm-7">

 <!-- <input type="text" class="datepicker" name="bdate"  value="<?php if(!empty($donar->bdate)){ echo $donar->bdate;}else{echo "N/A"; } ?>"> -->
 <div class="input-group">
        <div class="input-group-addon">
         <i class="fa fa-calendar">
         </i>
        </div>
        <input class="form-control" id="date" name="date" value="<?php echo $donar->bdate; ?>" type="text"/>
       </div>
      
  </div>




 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Living District:</div><div class="col-sm-7">

<select name="lidistrict" class="form-control" >

  <?php 
     foreach ($alldist as $homdis) { 
?>
  <option value="<?php echo $homdis->districtid; ?>" <?php 
if($donar->lidistrict == $homdis->districtid){ echo "selected"; }
?>
  ><?php echo $homdis->name; ?></option>
<?php 
}
?>
</select>

     
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Home District:</div><div class="col-sm-7">

<select name="homdistrict" class="form-control" >

  <option>Select District</option>
   <?php 
     foreach ($alldist as $homdis) { 
?>
  <option value="<?php echo $homdis->districtid; ?>" <?php 
if($donar->homdistrict == $homdis->districtid){ echo "selected"; }
?>
  ><?php echo $homdis->name; ?></option>
<?php 
}
?>
</select>

</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Natonality:</div><div class="col-sm-7">
<select name="hcountry" class="form-control" >

  <option>Select Country</option>
  <?php 
     foreach ($country as $con) { 
?>
  <option value="<?php echo $con->id; ?>" <?php 
if($donar->hcountry == $con->id){ echo "selected"; }
?>
  ><?php echo $con->name; ?></option>
<?php 
}
?>
</select>
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Facebook ID:</div><div class="col-sm-7"><input type="text" name="website" class="form-control" value="<?php if(!empty($donar->website)){ echo $donar->website;}else{echo "N/A"; } ?>"></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Present Address:</div><div class="col-sm-7">  <textarea name="paddress" id="" cols="40" rows="2" ><?php if(!empty($donar->paddress)){ echo $donar->paddress;} ?></textarea>
<p>Ex : Uttara,Dhaka,Bangladesh</p>
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >About:</div><div class="col-sm-7">  <textarea name="about" id="" cols="40" rows="3"><?php if(!empty($donar->about)){ echo $donar->about;} ?></textarea>
<p>EX : I am a student.I like programming.</p></div>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " ></div><div class="col-sm-7"><input type="submit"  value="Save_Profile"></div>

<?php } ?>


        </form>
     
    
       
       
       
       
       
       
       
       
   
   </div>
   </div>
   </div>
</div>




         </div>

</div>
</div>

   <!-- /.carousel -->

<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
  $(document).ready(function(){
    var date_input=$('input[name="date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'mm/dd/yyyy',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  })
</script>