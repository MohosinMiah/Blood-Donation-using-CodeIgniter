<?php 
$msg = $this->session->flashdata('msg');
if (isset($msg)) {
    echo $msg;
}
?>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>
 <div style="padding-top: 20px;padding-bottom: 20px;"></div>

<div class="container">
 
  <div class="col-md-4">
    
        <h4 style="color: green;">Update Your Profile</h4>
        
        <div class="profile-usermenu">
          <ul class="nav">

            <br>
            <li>
              <a href="<?php echo base_url(); ?>donor/editprofile">
              <i class="glyphicon glyphicon-user"></i>
              Edit Profile </a>
            </li>
            <br>

            <li>
              <a href="<?php echo base_url();?>donor/changepassword" >
              <i class="fa fa-key"></i>
              Change Password </a>
            </li>
            <br>

            <li>
              <a href="<?php echo base_url(); ?>donor/add_donationm">
              <i class="glyphicon glyphicon-edit"></i>
              Add a Donation </a>
            </li>
              <br>
            <li>
              <a href="<?php echo base_url(); ?>donor/history">
              <i class="fa fa-history"></i>
              Donation History </a>
            </li>
          </ul>
        </div>
        <!-- END MENU -->
      

  </div>

  <div class="col-md-8">

         <table class="table table-striped" style="font-size: 17px;">
    <thead>
      <tr>
        <th style="color: green;">Date of Donation</th>
        <th style="color: green;">Donated To</th>
        <th style="color: green;">Recipient Address</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($history as $key => $History) {
        ?>
      <tr>
       <td><?php echo $History->date; ?></td>
        <td><?php if($History->status == 2){ echo "Direct Patient";}else{ echo "To a blood Bank"; } ?></td>
        <td><?php echo $History->receptaddress; ?></td>
      </tr>
      <?php } ?>
     </tbody>
   </table>
       
       
       
       
       
       
   
   </div>
   </div>
   </div>
</div>




         </div>

</div>
</div>

   
<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
  $(document).ready(function(){
    var date_input=$('input[name="date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'mm/dd/yyyy',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  })
</script>