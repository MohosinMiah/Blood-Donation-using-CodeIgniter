<!-- Carousel
    ================================================== -->
<div class="container-fluid">
  
  <div class="row" style="margin-left: 100px;">
    <div class="col-md-6" style="background-image: url('<?php echo base_url(); ?>images/blood.jpg'); background-repeat: no-repeat;
   
    background-position: left;  "> <div class="container">
      <div class="jumbotron">
        <h3 style="color: green;margin-left: 100px;">Became a Produd of Blood Dooner</h3>
        <br>
        <div class="head-t " style="color: green;margin-left: 100px;">
				<ul class="card">
					
					<li><a href="<?php echo base_url();?>donor/login"  style="color:red;font-size: 20px;"><i  style="color:red;font-size: 20px;" class="fa fa-user" aria-hidden="true"></i>Login</a></li>
					<li><a href="<?php echo base_url(); ?>donor/register"  style="color:red;font-size:20px;"><i  style="color:red;font-size: 20px;" class="fa fa-arrow-right" aria-hidden="true"></i>Register</a></li>
				</ul>	
			</div>
      </div>
    </div></div>
     <div class="col-md-6" style="background-image: url('<?php echo base_url(); ?>images/blood-donation2.jpg'); background-repeat: no-repeat;wid
     width: 90px;background-position: left;  "> 
     <div class="container">
      <div class="jumbotron">
        <h3 style="color: green;margin-left: 50px;">Request For Blood</h3>
        <br>
        <div class="head-t " style="color: green;margin-left: 100px;">
				<ul class="card">
					
					<li><a href="<?php echo base_url(); ?>blood/request"  style="color:green;font-size:20px;"><i  style="color:green;font-size: 20px;" class="fa fa-heart" aria-hidden="true"></i>Request</a></li>
				</ul>	
			</div>
      </div>
    </div></div>
</div>

   <!-- /.carousel -->