<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title><?php 
  if (isset($title)) {
  	echo $title;
  }
?></title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta property="og:title" content="Vide" />
<meta name="keywords" content="Blood,Blood Donation , Blood Donation club , Blood Bangladesh , Blood Nonor , Request Blood,Blood donor largest club" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="<?php echo base_url(); ?>css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="<?php echo base_url(); ?>css/style.css" rel='stylesheet' type='text/css' />
<!-- js -->
   <script src="<?php echo base_url(); ?>js/jquery-1.11.1.min.js"></script>
<!-- //js -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="<?php echo base_url(); ?>js/move-top.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<link href="<?php echo base_url(); ?>css/font-awesome.css" rel="stylesheet"> 
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Noto+Sans:400,700' rel='stylesheet' type='text/css'>
<!--- start-rate---->
<script src="<?php echo base_url(); ?>js/jstarbox.js"></script>
	<link rel="stylesheet" href="<?php echo base_url(); ?>css/jstarbox.css" type="text/css" media="screen" charset="utf-8" />
		<script type="text/javascript">
			jQuery(function() {
			jQuery('.starbox').each(function() {
				var starbox = jQuery(this);
					starbox.starbox({
					average: starbox.attr('data-start-value'),
					changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
					ghosting: starbox.hasClass('ghosting'),
					autoUpdateAverage: starbox.hasClass('autoupdate'),
					buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
					stars: starbox.attr('data-star-count') || 5
					}).bind('starbox-value-changed', function(event, value) {
					if(starbox.hasClass('random')) {
					var val = Math.random();
					starbox.next().text(' '+val);
					return val;
					} 
				})
			});
		});
		</script>
<!---//End-rate  -->

</head>
<body>
<div class="header">

		<div class="container">
			
			<div class="logo">
				<h1 ><a href="<?php echo base_url(); ?>" style="color: green;"> <?php $this->session->userdata('name');
             foreach ($titleoption as $title) {
                echo $title->webtitle;
                ?> 
					<span><?php 
                                   echo $title->webslang;
                           }
					?></span></a></h1>
			</div>
			<div class="head-t">
				<ul class="card">
					<li><a href="<?php echo base_url();?>blood/request" ><i class="fa fa-heart" aria-hidden="true"></i>Request For Blood</a></li>
					<?php 
             $login =  $this->session->userdata('login');
                       if ($login !== TRUE) {  ?>
                        	<li><a href="<?php echo base_url();?>donor/login" ><i class="fa fa-user" aria-hidden="true"></i>Login</a></li> <?php
                        } 
                        	?>
                        	
                        	
					

					<li><a href="<?php echo base_url(); ?>donor/register" ><i class="fa fa-arrow-right" aria-hidden="true"></i>Register</a></li>
					
					<li><a href="<?php echo base_url(); ?>recent/request"  ><i class="fa fa-file-text-o" aria-hidden="true"></i>All Request for Blood</a></li>
			<?php 
             $login =  $this->session->userdata('login');
                       if ($login == TRUE) {  ?>
					<li><a href="<?php echo base_url();?>user/logout" ><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
					<?php } ?>
				</ul>	
			</div>
			
			<div class="header-ri">
				<ul class="social-top">
<?php 

foreach ($connected as  $ft) {
	
?>
					<li><a href="<?php echo $ft->facebook; ?>" class="icon facebook"><i class="fa fa-facebook" aria-hidden="true"></i><span></span></a></li>
					<li><a href="<?php echo $ft->twitter; ?>" class="icon twitter"><i class="fa fa-twitter" aria-hidden="true"></i><span></span></a></li>
<?php } ?>
				</ul>	
			</div>
		

				<div class="nav-top">
					<nav class="navbar navbar-default">
					
					<div class="navbar-header nav_2">
						<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						

					</div> 
					<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
						<ul class="nav navbar-nav ">
							<li class=" active"><a href="<?php echo base_url(); ?>" class="hyper "><span>Home</span></a></li>	
							
							<li class="dropdown ">
								<a href="#" class="dropdown-toggle  hyper" data-toggle="dropdown" ><span>Donors by group<b class="caret"></b></span></a>
								<ul class="dropdown-menu multi" >
									<div class="row">
										<?php 
                                     foreach ($group as  $bgv) {

										?>
										<div class="col-sm-3">
											<ul class="multi-column-dropdown">
			                             
												<li><a href="<?php echo base_url(); ?>blood/group/<?php echo url_title($bgv->group); ?>/<?php echo $bgv->bloodid; ?>"><i class="fa fa-angle-right" aria-hidden="true"></i><?php echo $bgv->group; ?></a></li>
										
											</ul>
										
										</div>
										<?php }?>
										
										
								</ul>
							</li>
							
							
							<li><a href="<?php echo base_url();?>blood/ditricts" class="hyper"> <span>Donors by District</span></a></li>
							<li><a href="<?php echo base_url(); ?>recent/request" class="hyper"> <span>All Request</span></a></li>

							</span></a></li>
							<li><a href="<?php echo base_url();?>blood/request" class="hyper"><span>Request for blood</span></a></li>
<?php 
    foreach ($allPages as $key => $page) {
    	
?>
							<li><a href="<?php echo base_url();?>pages/viewpage/<?php echo url_title($page->title);?>/<?php echo $page->pageid;?>" class="hyper"><span><?php echo $page->title;?></span></a></li>
						<?php } ?>
							<li><a href="<?php echo base_url();?>contact" class="hyper"><span>Contact</span></a></li>

						</ul>

					</div>
					</nav>
					<?php 
             $login =  $this->session->userdata('login');
                       if ($login == TRUE) {  ?>
					 <div class="cart" >
					<!-- <i class="fa fa-user" aria-hidden="true"></i> -->
					<?php $donarname = $this->session->userdata('name');?>
						<a href="<?php echo base_url();?>/donor/profile"><span data-toggle="tooltip" title="<?php echo $donarname; ?>" style="font-size: 27px;color: green;" class="fa fa-user"></span></a>
					</div>
					<?php } ?>
					<div class="clearfix"></div>
				</div>
					
				</div>			
</div>