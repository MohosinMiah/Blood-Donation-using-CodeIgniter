<div class="container">
<div class="footerarea" style="background-color: gainsboro;padding-top: 10px;padding-bottom: 10px;" >
		
		
			
			<center><p style="color:#fff;"><footer>&copy; Copyright <?php echo date('Y'); ?> <?php 


        foreach ($mediaoption as  $value) {
        	echo $value->copyright;
        }
			?></footer> </p></center>
				
		</div>
</div>
	
	

<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
<!-- for bootstrap working -->
		<script src="<?php echo base_url(); ?>js/bootstrap.js"></script>

<script>  $(document).ready(function(){
  
 $('[data-toggle="tooltip"]').tooltip();   
});

</script>
</body>
</html>