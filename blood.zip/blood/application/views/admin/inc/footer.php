<div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright <a href="<?php echo base_url(); ?>">Blood Donation Club</a>. All Rights Reserved.
        </p>
    </div>
</body>
</html>