<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<form action="<?php echo base_url();?>/user/adminlogin" method="post">
			<h1>Admin Login</h1>
			<?php 
$ermsg = $this->session->flashdata('msg');
if (isset($ermsg)) {
	echo $ermsg;
}
?>
			<div>
				<input type="text" placeholder="email"  name="email"/>
			</div>
			<div>
				<input type="password" placeholder="password" name="password"/>
				<input type="password" placeholder="password" name="password"/>
				
			</div>	

			<div>
				<input type="submit" value="Log in" />
				<input type="submit" value="Log in" />
				<a href="">Forgot Password</a>
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="#">Blood Donation Club</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>