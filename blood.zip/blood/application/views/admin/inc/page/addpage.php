 <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Page</h2>
                <h2><?php 

$ermsg = $this->session->flashdata('message');
if (isset($ermsg)) {
    echo $ermsg;
}
                ?></h2>
                <div class="block">               
                 <form action="<?php echo base_url();?>pages/savepage" method="post" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input type="text" name="title" placeholder="Enter page name..." class="medium" />
                            </td>
                        </tr>
                     
                       
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce"></textarea>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>