 <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Page</h2>
                <h2><?php 

$ermsg = $this->session->flashdata('message');
if (isset($ermsg)) {
    echo $ermsg;
}
                ?></h2>
                <div class="block">               
                 <form action="<?php echo base_url();?>pages/updatecurrentpage" method="post" enctype="multipart/form-data">
                    <table class="form">
                       <?php 
                  foreach ($editpage as  $updatepage) {
                       ?>
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                            <input type="hidden" name="pageid" value="<?php echo $updatepage->pageid; ?>">
                                <input type="text" name="title" value="<?php echo $updatepage->title; ?>" class="medium" />
                            </td>
                        </tr>
                     
                       
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea name="body" class="tinymce"><?php echo $updatepage->body; ?></textarea>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                            <style>
                                .button{
                                    border: 1px solid #ddd;
    color: #444;
    cursor: pointer;
    font-size: 20px;
    padding: 2px 10px;
                                }
                            </style>
                                <input type="submit" name="submit" Value="Update" />
                                 <?php $name = $this->session->userdata('roll');
                           if ($name == 2) {
                            ?>
                                <a onclick="return confirm('Are you sure to delete this page ..');" class="button" href="<?php echo base_url();?>pages/deletepage/<?php echo $updatepage->pageid; ?>">Delete</a>
                            <?php } ?>
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
                <?php } ?>
            </div>
        </div>