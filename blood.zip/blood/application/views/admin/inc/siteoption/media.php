<div class="grid_10">
        
            <div class="box round first grid">
                <h2>Update Social Media</h2>
                <?php 
     $ermsg = $this->session->flashdata('message');
     if (isset($ermsg)) {
         echo $ermsg;
     }


                ?>
                <div class="block">               
                 <form action="<?php echo base_url(); ?>/media/changemedia" method="post">
                 <?php
                   foreach ($mediaoption as  $Social) {
                 ?>
                    <table class="form">                    
                        <tr>
                            <td>
                                <label>Facebook</label>
                            </td>
                            <td>
                                <input type="text" name="facebook" value="<?php echo  $Social->facebook; ?>" class="medium" />
                            </td>
                        </tr>
                         <tr>
                            <td>
                                <label>Twitter</label>
                            </td>
                            <td>
                            <input type="hidden" name="mediaid" value="<?php echo  $Social->mediaid; ?>">
                                <input type="text" name="twitter" value="<?php echo  $Social->twitter; ?>" class="medium" />
                            </td>
                        </tr>
                        
                        
                         <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    <?php } ?>
                    </form>
                </div>
            </div>
        </div>