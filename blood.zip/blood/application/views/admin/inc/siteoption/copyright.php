<div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Copyright Text</h2>
                <div class="block copyblock"> 
                 <?php 
     $ermsg = $this->session->flashdata('message');
     if (isset($ermsg)) {
         echo $ermsg;
     }
            foreach ($mediaoption as  $value) {
                 ?>
  <form action="<?php echo base_url(); ?>media/changecopyright" method="post">

                    <table class="form">					
                        <tr>
                            <td>
                            <input type="hidden" name="id" value="<?php echo $value->id; ?>"  >
                                <input type="text" value="<?php echo $value->copyright; ?>" name="copyright" class="large" />
                            </td>
                        </tr>
						
						 <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>