<div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Site Title and Description</h2>
                <div class="block sloginblock">    
              <?php
            $ermsg = $this->session->flashdata('message');
            if (isset($ermsg)) {
                echo $ermsg;
            }

            foreach ($titleoption as $key => $title) {
                
                ?>         
                               
<?php echo validation_errors(); ?>

<?php echo form_open('title/changetitle'); ?>
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Website Title</label>
                            </td>
                            <td>
                            <input type="hidden" name="ID" value="<?php echo $title->titleid; ?>">
                                <input type="text" value="<?php echo $title->webtitle; ?>"  name="title" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Website Slogan</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $title->webslang; ?>"  name="slogan" class="medium" />
                            </td>
                        </tr>
						 
						
						 <tr>
                            <td>
                            </td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="clear">
        </div>