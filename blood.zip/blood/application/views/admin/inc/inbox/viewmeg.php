 <div class="grid_10">
		
            <div class="box round first grid">
                <h2>View Message</h2>
                <div class="block">  
                <?php 
foreach ($viewemail as $key => $mail) {
   ?>             
                 <form action="<?php echo base_url();?>inbox/seen"" method="post" >
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Subject</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $mail->subject;?>" readonly class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input type="text" value="<?php echo $mail->email;?>" readonly  class="medium" />
                            </td>
                        </tr>
                     
                       
                    
                       
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" readonly><?php echo $mail->body;?>  </textarea>
                                <input type="hidden" name="id" value="<?php echo $mail->id; ?>">
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" value="Back">
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>