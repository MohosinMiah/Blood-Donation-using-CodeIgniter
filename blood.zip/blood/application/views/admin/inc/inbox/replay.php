<div class="grid_10">
    
            <div class="box round first grid">
                <h2>Replay Message</h2>

               <div class="block copyblock"> 
                 
<?php 
         $ermsg = $this->session->flashdata('message');
                  if (isset($ermsg)) {
                      echo  $ermsg;
                  }

                ?>
<?php echo validation_errors(); ?>

<?php echo form_open('inbox/replay'); ?>

                    <table class="form">          
                        <tr>
                        <td>Your Subject</td>
                            <td>
                                <input type="text" name="subject" placeholder="Enter Subject..." class="medium" required="" />
                            </td>
                        </tr>
                         <tr>
                        <td>Email : </td>
                            <td>
              <?php 
   foreach ($emailcr as $key => $email) { ?>
                                <input type="email" name="email"  title="Read Only" placeholder="Enter userr Email..." class="medium"  value="<?php echo $email->email; ?>" readonly />
                                <input type="hidden" name="id" value="<?php echo $email->id; ?>">
          <?php } ?>
                            </td>
                        </tr>
                        <tr>
                        <td>Your Message : </td>
                            <td>
                               <textarea name="body" id="" cols="30" rows="10"></textarea>
                            </td>
                        </tr>
                                              
                        <tr>
                       
                        <tr>
                      
                        

            <tr> <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Replay" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>