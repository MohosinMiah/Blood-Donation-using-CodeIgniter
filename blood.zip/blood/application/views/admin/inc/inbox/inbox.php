
 <div class="grid_10">
            <div class="box round first grid">
            <h2>Unseen Message(Inbox)</h2>
            <?php 
          $msg = $this->session->flashdata('msg');
          if (isset($msg)) {
              echo $msg;
          }

            ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
                    <thead>
                        <tr>
                            <th width="5%">#</th>
                            <th width="10%">Subject</th>
                            <th  width="50%">Body</th>
                            <th width="10%" >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $i=0;
                       foreach ($inboxmessagelist as  $email) {
                        $i++;
                    ?>
                        <tr class="odd gradeX">
                            <td><?php echo $i; ?></td>
                            <td><?php echo $email->subject;?></td>
                            <td><?php echo word_limiter($email->body,20);?></td>
                             <td><a href="<?php echo base_url(); ?>inbox/viewmessage/<?php echo $email->id;?>">View</a> || <a href="<?php echo base_url(); ?>inbox/replaymessage/<?php echo $email->id;?>">Replay</a> || <a onclick="return confirm('Are you sure to delete !..');" href="<?php echo base_url(); ?>inbox/deletemsg/<?php echo $email->id; ?>">Delete</a></td>
                        </tr>
                        <?php } ?>
                        
                    </tbody>
                </table>
               </div>
            </div>
        </div>



 <div class="grid_10">
            <div class="box round first grid">
            <h2>Seen Message(Inbox)</h2>
                <div class="block">        
                    <table class="data display datatable" id="example">
                    <thead>
                        <tr>
                            <th width="5%">#</th>
                            <th width="10%">Subject</th>
                            <th  width="50%">Body</th>
                            <th width="10%" >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $i=0;
                       foreach ($seeninboxmessagelist as  $email) {
                        $i++;
                    ?>
                        <tr class="odd gradeX">
                            <td><?php echo $i; ?></td>
                            <td><?php echo $email->subject;?></td>
                            <td><?php echo word_limiter($email->body,25);?></td>
                             <td><a href="<?php echo base_url(); ?>/inbox/viewmessage/<?php echo $email->id;?>">View</a> || <a onclick="return confirm('Are you sure to delete !..');" href="<?php echo base_url(); ?>inbox/deletemsg/<?php echo $email->id; ?>">Delete</a></td>
                        </tr>
                        <?php } ?>
                        
                    </tbody>
                </table>
               </div>
            </div>
        </div>



































































          <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/text.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/grid.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/layout.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/nav.css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ie6.css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/ie.css" media="screen" /><![endif]-->
    <link href="<?php echo base_url(); ?>css/table/demo_page.css" rel="stylesheet" type="text/css" />
    <!-- BEGIN: load jquery -->
    <script src="<?php echo base_url(); ?>js/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-ui/jquery.ui.core.min.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui/jquery.ui.widget.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui/jquery.ui.accordion.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui/jquery.effects.core.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui/jquery.effects.slide.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui/jquery.ui.mouse.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/jquery-ui/jquery.ui.sortable.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>js/table/jquery.dataTables.min.js" type="text/javascript"></script>
    <!-- END: load jquery -->
    <script type="text/javascript" src="<?php echo base_url(); ?>js/table/table.js"></script>
    <script src="<?php echo base_url(); ?>js/setup.js" type="text/javascript"></script>
    <script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
			setSidebarHeight();


        });
    </script>