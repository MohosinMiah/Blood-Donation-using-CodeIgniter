<div class="grid_10">
		
            <div class="box round first grid">
                <h2>Change Password</h2>
               <div class="block copyblock"> 
                            
<?php 
         $ermsg = $this->session->flashdata('message');
                  if (isset($ermsg)) {
                      echo  $ermsg;
                  }

                ?>
<?php echo validation_errors(); ?>

<?php echo form_open('admin/adminchangedonorpass'); ?>
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="password" name="password" placeholder="Enter Old Password..." class="medium" />
                            </td>
                        </tr>
                        <tr> 
                        <tr>
                            <td>
                                <input type="password" name="upassword" placeholder="Enter New Password..." class="medium" />
                            </td>
                        </tr>
                        <tr> 
                            <td>
                                <input onclick="return confirm('Are you sure to update your password')" type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>