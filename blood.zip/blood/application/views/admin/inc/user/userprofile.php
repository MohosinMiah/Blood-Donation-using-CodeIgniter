<div class="grid_10">
		
            <div class="box round first grid">
                <h2>User Profile</h2>

               <div class="block copyblock"> 
                 
<?php 
         $ermsg = $this->session->flashdata('message');
                  if (isset($ermsg)) {
                      echo  $ermsg;
                  }

                ?>
<?php echo validation_errors(); ?>

<?php echo form_open('user/updateuser'); ?>
<?php 

foreach ($userlist as $key => $user) {
?>
                    <table class="form">					
                        <tr>
                        <td>Name</td>
                            <td>
                                <input type="text" name="name" value="<?php echo $user->name;?>" />
                            </td>
                        </tr>
                        <tr>
                        <td>Address : </td>
                            <td>
                                <input type="text" name="address" value="<?php echo $user->address;?>"class="medium" />
                            </td>
                        </tr>
                                                <tr>
                        <td>Phone : </td>
                            <td>
                                <input type="text" name="Phone" value="<?php echo $user->Phone;?>" class="medium" />
                                <input type="hidden" name="userId" value="<?php echo $user->userId;?>">
                            </td>
                        </tr>
                       
                        
                        <tr>
                        <td>User Level : </td>
                            <td>
                               <select name="roll">
                               <option> Select User Roll </option>
                               	<option 
                                    <?php 
                      if ($user->roll == 2) {
                          echo "selected";
                      }
                                    ?>
                                value="2">Administrator</option>
                               	<option 
                      <?php 
                      if ($user->roll == 3) {
                          echo "selected";
                      }?>
                                value="3">Author</option>
                               	<option 

            <?php 
                      if ($user->roll == 4) {
                          echo "selected";
                      }?>
                                value="4">Editor</option>
                               </select>
                            </td>
                        </tr>

						<tr> <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } ?>
                </div>
            </div>
        </div>