
 <div class="grid_10">
            <div class="box round first grid">
            <h2>All Donor List 

            </h2>
            <?php 
          $msg = $this->session->flashdata('msg');
          if (isset($msg)) {
              echo $msg;
              
          }

            ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
                    <thead>
                        <tr>
                            <th style="text-align: left;">Name</th>
                            <th>Blood Group</th>
                            <th>Living District</th>
                            <th>Gender</th>
                            <th>Contact</th>
                            <th>Donor Status</th>
                            <th>Num. Donates</th>
                            <th width="10%" >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                   
                       foreach ($alldonar as  $donor) {
                       
                    ?>
                        <tr class="odd gradeX">
                    
                            <td><?php echo $donor->name;?></td>
                            <td>
                                <?php 
     foreach ($group as $bg) { if($donor->bgroup == $bg->bloodid){ echo $bg->group; } }
?>
                            </td>
                            <td>
<?php foreach ($districtall as $dis) { if($donor->lidistrict == $dis->districtid){ echo $dis->name; } }
?>

                            </td>
                            <td class="center"><?php if($donor->gender == 3){echo "Male";} ?>  
  <?php if($donor->gender == 4){echo "Female";} ?>  
  <?php if($donor->gender == 0){echo "Undefined";} ?>  </td>
                            <td><?php $contact=  $donor->contact; if(!empty($contact)){ echo $donor->contact;}else{ echo "N/A";}; ?></td>
                            <td><?php 
if($donor->status == 3){ ?>
<img src="<?php echo base_url(); ?>images/agree.png"  data-toggle="tooltip" title ="<?php echo $donor->name; ?> Interested to Donate His Blood" alt="Agree">
<?php 
}elseif ($donor->status == 4) {  ?>
<img src="<?php echo base_url(); ?>images/notinterested.png" data-toggle="tooltip" title ="<?php echo $donor->name; ?> Not-Interested to Donate His Blood" alt="Not-Interested">
<?php }else{  ?>
<img src="<?php echo base_url(); ?>images/notready.png" data-toggle="tooltip" title ="<?php echo $donor->name; ?> Not Ready to Donate His Blood" alt="Not Ready">
<?php
}
?></td>
                            <td ><button type="button"><span class="badge"><?php 
                            $usid = $donor->userid;
                            $this->user_model->hitosyid($usid);
                        echo $this->session->userdata('tohistoryid');
                             ?></span> </button> </td>

                        
        <td><a href="<?php echo base_url(); ?>donor/viewprofile/<?php echo $donor->userid; ?>"  target="_blank">View</a> || <a  onclick="return confirm('Are You Sure To Delete Donor')" href="<?php echo base_url(); ?>donor/delete/<?php echo $donor->userid; ?>/<?php echo $donor->lidistrict; ?>">Delete</a> </td>
<?php } ?>
                        </tr>
                    </tbody>
                </table>

               </div>
            </div>
        </div>



<link rel="stylesheet" href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>    <script type="text/javascript">

       
           

            $('#example').dataTable( {
  "pageLength": 20,
   "lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
} );

  
    </script>