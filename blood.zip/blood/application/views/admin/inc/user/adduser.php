<div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New userr</h2>

               <div class="block copyblock"> 
                 
<?php 
         $ermsg = $this->session->flashdata('message');
                  if (isset($ermsg)) {
                      echo  $ermsg;
                  }

                ?>
<?php echo validation_errors(); ?>

<?php echo form_open('userr/saveuser'); ?>

                    <table class="form">					
                        <tr>
                        <td>Name</td>
                            <td>
                                <input type="text" name="name" placeholder="Enter userr Name..." class="medium" required="" />
                            </td>
                        </tr>
                        <tr>
                        <td>Address : </td>
                            <td>
                                <input type="text" name="address" placeholder="Enter userr Address..." class="medium"  required="" />
                            </td>
                        </tr>
                                                <tr>
                        <td>Phone : </td>
                            <td>
                                <input type="number" name="Phone" placeholder="Enter userr Phone number..." class="medium"  required="" />
                            </td>
                        </tr>
                        <tr>
                        <td>Email : </td>
                            <td>
                                <input type="email" name="email"  placeholder="Enter userr Email..." class="medium"  required="" />
                            </td>
                        </tr>
                        <tr>
                        <td>Password : </td>
                            <td>
                                <input type="text" name="password" placeholder="Enter userr Password..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                        <td>userr Level : </td>
                            <td>
                               <select name="roll">
                               <option> Select userr Roll </option>
                               	<option value="2">Administrator</option>
                               	<option value="3">Author</option>
                               	<option value="4">Editor</option>
                               </select>
                            </td>
                        </tr>

						<tr> <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Adduserr" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>