<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Login</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<form action="<?php echo base_url();?>user/adminlogin" method="post">
			<h1>Admin Login </h1>

			<div>
				<input type="text" placeholder="Email " required="" name="email"/>
			</div>
			<div>
				<input type="password" placeholder="Password" required="" name="password"/>
			</div>
			<div>
				<input type="submit" value="Log in" />
				<a href="<?php echo base_url(); ?>admin/forgotpassword">Forgot Password</a>

			</div>
		</form><!-- form -->
		<div class="button">
			<a href="<?php echo base_url();?>">Blood Donation Club</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>