<div class="grid_10">
            <div class="box round first grid">
                <h2>User List</h2>

<?php 
         $ermsg = $this->session->flashdata('message');
                  if (isset($ermsg)) {
                      echo  $ermsg;
                  }

                ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>

						<tr>
							<th style="text-align: left;">User Name</th>
							<th style="text-align: left;">Address</th>
												
 <?php $name = $this->session->userdata('roll');
                           if ($name == 2) {
               ?>
							<th style="text-align: left;">Phone</th>
							<th style="text-align: left;">Email</th>

						

						   <th style="text-align: left;">Action</th>
						<?php } ?>
						
							<th style="text-align: left;">Roll</th>
</tr>
					</thead>
					<tbody>
					<?php 
                 foreach ($userlist as  $user) {
                 	
					?>
						<tr class="odd gradeX">
							<td style="width: 10%;"><?php echo $user->name; ?></td>
							<td style="width: 10%;"><?php echo $user->address; ?>
								
							</td>

 <?php $name = $this->session->userdata('roll');
                           if ($name == 2) {
               ?>
							<td><?php echo $user->Phone; ?></td>
							<td style="width: 10%;"><?php echo $user->email; ?></td>
							<?php } ?>
							<td style="width: 10%;"><?php 

							 switch ($user->roll) {
							 	case '2':
							 		echo "Administrator";
							 		break;
							 	case '3':
							 		echo "Author";
							 		break;
							 	case '3':
							 		echo "Editor";
							 		break;
							 	
							 	default:
							 		# code...
							 		break;
							 }


							  ?>
							  	
							  </td>
				<td style="width: 10%;">
 <?php $name = $this->session->userdata('roll');
                           if ($name == 2 ) {
               ?>
					<a href="<?php echo base_url(); ?>userr/edituser/<?php echo $user->userId; ?>">Edit</a>|| 
                    
					<a href="<?php echo base_url(); ?>userr/deleteuser/<?php echo $user->userId; ?>" onclick="return confirm('Are You sure to Detele User')">Delete</a>
<?php } ?>
				</td>
						</tr>
						<?php 
					}
						?>
					</tbody>
				</table>
               </div>
            </div>
        </div>