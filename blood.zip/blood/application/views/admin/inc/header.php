<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title> <?php if(isset($title)){ echo $title; }?></title>
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/reset.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/text.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/grid.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/layout.css" media="screen" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>acss/nav.css" media="screen" />
    <link href="<?php echo base_url(); ?>acss/table/demo_page.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/acss/font-awesome.min.css">
    <!-- BEGIN: load jquery -->
    <script src="<?php echo base_url(); ?>ajs/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.ui.core.min.js"></script>
    <script src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.ui.widget.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.ui.accordion.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.effects.core.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.effects.slide.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.ui.mouse.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>ajs/jquery-ui/jquery.ui.sortable.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>ajs/table/jquery.dataTables.min.js" type="text/javascript"></script>
    <!-- END: load jquery -->
    <script type="text/javascript" src="<?php echo base_url(); ?>ajs/table/table.js"></script>
    <script src="<?php echo base_url(); ?>ajs/setup.js" type="text/javascript"></script>
	 <script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>

</head>
<body>
    <div class="container_12">
        <div class="grid_12 header-repeat">
            <div id="branding">
                <div class="floatleft logo">
                    <img src="<?php echo base_url(); ?>aimg/livelogo.png" alt="Logo" />
				</div>

				<div class="floatleft middle">
					<h1>Blood Donation Club</h1>
                    <?php 
   echo $this->session->flashdata('name');
                    ?>
					<p>www.blooddonation.com</p>
				</div>
                <div class="floatright">
                    <div class="floatleft">
                        <img src="<?php echo base_url(); ?>aimg/img-profile.jpg" alt="Profile Pic" /></div>
                    <div class="floatleft marginleft10">
                        <ul class="inline-ul floatleft">

                            <li style="font-size: 20px;">Hello  
<?php 
      $name = $this->session->userdata('name');
      if (isset($name)) {
          echo $name;
      }else
                            ?>
                            </li>
                            <li style="font-size: 17px;" ><a href="<?php echo base_url(); ?>admin/logout">Logout</a></li>
                        </ul>
                    </div>
                </div>
                <div class="clear">
                </div>
            </div>
        </div>
        <div class="clear">
        </div>
        <div class="grid_12">
            <ul class="nav main">
                <li class="ic-dashboard"><a href="<?php echo base_url(); ?>dashbord"><span>Dashboard</span></a> </li>
                 <?php 
                      $name = $this->session->userdata('roll');
                           if ($name == 2) {
               ?>
                <li class="ic-form-style"><a href="<?php echo base_url(); ?>userr/adduser"><span>Add User</span></a></li>
                 <?php 
                      } ?>
                                      <li class="ic-form-style"><a href="<?php echo base_url(); ?>userr/userlist"><span>User List</span></a></li>

               
                <!-- <li class="ic-form-style"><a href="<?php echo base_url(); ?>/user/userprofile"><span>User Profile</span></a></li> -->
				<li class="ic-typography"><a href="<?php echo base_url(); ?>userr/changepassword"><span>Change Password</span></a></li>
				<li class="ic-grid-tables"><a href="<?php echo base_url(); ?>inbox/inboxmessage"><span>Inbox(<?php  if (isset($countallunseenmsg)) {
                    echo $countallunseenmsg;
                }else{
              echo 'Empty';
                    } ?>)</span></a></li>
                     <?php 
                      $name = $this->session->userdata('roll');
                           if ($name == 2) {
               ?>
                <li class="ic-charts"><a href="<?php echo base_url(); ?>userr/alldonor"  ><span>All Donor</span></a></li>
                   <?php } ?>
                <li class="ic-charts"><a href="<?php echo base_url(); ?>" target="_blank" ><span>Visit Website</span></a></li>
       
            </ul>
        </div>
        <div class="clear">
        </div>