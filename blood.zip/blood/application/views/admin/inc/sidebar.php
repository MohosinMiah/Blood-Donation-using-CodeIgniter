<div class="grid_2">
            <div class="box sidemenu">
                <div class="block" id="section-menu">
                    <ul class="section menu">
                       <li><a class="menuitem">Site Option</a>
                            <ul class="submenu">
                                <li><a href="<?php echo base_url(); ?>title/updatetitle">Title & Slogan</a></li>
                                <li><a href="<?php echo base_url(); ?>media/updatemedia">Social Media</a></li>
                                <li><a href="<?php echo base_url(); ?>media/updatecopyright">Copyright</a></li>
                                
                                
                            </ul>
                        </li>
						
                         <li><a class="menuitem">Update Pages</a>
                            <ul class="submenu">
                         <?php 
                foreach ($allPages as  $page) {   ?>
                                      
                                <li><a href="<?php echo base_url();?>pages/updatepage/<?php echo $page->pageid;?>"><?php echo $page->title; ?></a></li>
                                <?php } ?>

                                <li><a href="<?php echo base_url(); ?>pages/page">Add Page</a></li>
                            </ul>
                        </li>
                        </ul>
                </div>
            </div>
        </div>