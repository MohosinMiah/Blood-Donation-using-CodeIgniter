<?php if(isset($header)){ echo $header; }?>
<?php if(isset($sidebar)){ echo $sidebar; }?>
<?php if(isset($main)){ echo $main; }?>
<?php if(isset($footer)){ echo $footer; }?>
        
