<?php
class pages_model extends CI_Model {
function __construct() {
parent::__construct();
}
 

        public function savepage($data)
        {
        
                $this->db->insert('tbl_page', $data);
        }

        public function pages()
        {
                $this->db->select('*');
               $this->db->from('tbl_page');
              
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
    public function view($title)
    {
         $this->db->select('*');
               $this->db->from('tbl_page');
                              $this->db->where('pageid',$title);

                $query = $this->db->get();
                $result = $query->result();
                return $result;
                    }
public function pagesingle($id)
{
  $this->db->select('*');
               $this->db->from('tbl_page');
                              $this->db->where('pageid',$id);

                $query = $this->db->get();
                $result = $query->result();
                return $result;
}
        public function editpage($id)
        {
                $this->db->select('*');
                $this->db->from('tbl_page');
                $this->db->where('pageid',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function category($catid)
        {
                $this->db->select('*');
                $this->db->from('tbl_category');
                $this->db->where('catId',$catid);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
public function delimg($data)
{
        $this->db->select('*');
        $this->db->from('tbl_post');
    $this->db->where('postid',$data['postid']);
    $query =  $this->db->get();
  $result = $query->result();
                foreach ($result as $key => $value) {
                        $filename = base_url().'uploads/'.basename($value->image);
                         if (file_exists($filename))
        {
            unlink($filename);
        }
                }
}
        public function updatecurrentpage($data)
        {
         $this->db->set('title',$data['title']);
         $this->db->set('body',$data['body']);
         $this->db->where('pageid',$data['pageid']);
         $this->db->update('tbl_page');
        }
        

  public function deletepage($id)
  {
          $this->db->where('pageid',$id);
          $this->db->delete('tbl_page');
  }
       
// view start here 

  public function single($title)
  {
               $this->db->select('*');
                $this->db->from('tbl_post');
                $this->db->where('postid',$title);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
  }

public function postsbycat($catId)
{
    $this->db->select('*');
                $this->db->from('tbl_post');
                $this->db->where('postcat',$catId);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
}





}