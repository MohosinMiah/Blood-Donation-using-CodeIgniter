
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class author_model extends CI_Model {

public function addauthorname($data)
{
	$this->db->insert('tbl_author',$data);
	

}

public function authorlist()
{
	$this->db->select('*');
	$this->db->from('tbl_author');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function showauthorbyid($id)
{
	$this->db->select('*');
	$this->db->from('tbl_author');
	$this->db->where('author_id',$id);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function updateauthorin($data)
{
	$this->db->set('author_name',$data['author_name']);
	$this->db->where('author_id',$data['author_id']);
	$this->db->update('tbl_author');
}

public function deleteauthor($id)
{
	$this->db->where('author_id',$id);
	$this->db->delete('tbl_author');
}

}