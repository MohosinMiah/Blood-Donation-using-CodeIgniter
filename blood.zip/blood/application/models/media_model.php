<?php
class media_model extends CI_Model {
function __construct() {
parent::__construct();
}

  public function showmedia()
        {
                $this->db->select('*');
                $this->db->from('tbl_media');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }


       

        public function changetitle($data)
        {
                $this->db->set('facebook',$data['facebook']);
                $this->db->set('twitter',$data['twitter']);
                
                $this->db->where('mediaid',$data['mediaid']);
                $this->db->update('tbl_media');
        }

        public function showcopyright()
        {
             $this->db->select('*');
                $this->db->from('tbl_copyright');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function changecopyright($data)
        {
            $this->db->set('copyright',$data['copyright']);
                $this->db->where('id',$data['id']);
                $this->db->update('tbl_copyright');
        }

}