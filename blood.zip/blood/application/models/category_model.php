<?php
class category_model extends CI_Model {
  public $getnum;

function __construct() {
parent::__construct();
}

        public function insertcategory($data)
        {
        
                $this->db->insert('tbl_category', $data);
        }
       public function insertcatimage($data)
       {
               $this->db->insert('tbl_catimage',$data);
       }
       public function insertcarsoul($data)
       {
               $this->db->insert('tbl_slider',$data);
       }
        public function categorylist()
        {
                $this->db->select('*');
                $this->db->from('tbl_category');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function firstcatall()
        {
                $this->db->select('*');
                $this->db->from('tbl_category');
                $this->db->where('catname','Kitchen');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
       public function secondcatall()
        {
                $this->db->select('*');
                $this->db->from('tbl_category');
                $this->db->where('catname','PersonalCar');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
      
         public function sliderlist()
         {
                 $this->db->select('*');
                $this->db->from('tbl_slider');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
         }

   public function fontviewcarsel()
   {
     $this->db->select('*');
                $this->db->from('tbl_slider');
                $this->db->limit(3);
                $this->db->order_by('id','DESC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
   }

     public function catimagelist()
     {
             $this->db->select('*');
             $this->db->from('tbl_catimage');
             $query = $this->db->get();
             $result = $query->result();
             return $result;
     }

    public static  function getCount(){

    $this->db->select('*');
    $this->db->count('id');
    $this->db->from('tbl_catimage');
    $query = $this->db->get();
    $result = $this->db->result($query);
    $getnum = $result;
    return $getnum;
}

     public function sfibtwo()
     {
       $this->db->select('*');
      $this->db->from('tbl_catimage');
     $this->db->limit(3);
       $this->db->order_by('id','DESC');
        $query = $this->db->get();
             $result = $query->result();
             return $result;
       
     }

      public function favcategory()
      {
              $this->db->select('*');
              $this->db->from('tbl_favoritecat');
              $query = $this->db->get();
              $result = $query->result();
              return $result;
      }

        public function showcatbyid($id)
        {
                $this->db->select('*');
                $this->db->from('tbl_category');
                $this->db->where('catId',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }


        public function showtitle($id)
        {
                $this->db->select('*');
                $this->db->from('tbl_slider');
                $this->db->where('id',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
        public function showfavcategory($id)
        {
                $this->db->select('*');
                $this->db->from('tbl_catimage');
                $this->db->where('id',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function updatecategory($data)
        {
                $this->db->set('catname',$data['catname']);
                $this->db->set('subcat',$data['subcat']);
                $this->db->where('catId',$data['catId']);
                $this->db->update('tbl_category');
        }
        public function updatecatimage($data)
        {
                $this->db->set('title',$data['title']);
                $this->db->set('des',$data['des']);
                $this->db->where('id',$data['id']);
                $this->db->update('tbl_catimage');
        }
        public function updatecatimagewithimage($data)
        {
                $this->db->set('title',$data['title']);
                $this->db->set('des',$data['des']);
                $this->db->set('image',$data['image']);
                $this->db->where('id',$data['id']);
                $this->db->update('tbl_catimage');
        }


        public function updatecarsoul($data)
        {
                $this->db->set('link',$data['link']);
                $this->db->where('id',$data['id']);
                $this->db->update('tbl_slider');
        }

         public function updatewithcarsoul($data)
        {
                $this->db->set('link',$data['link']);
                $this->db->set('sliderimg',$data['sliderimg']);
                $this->db->where('id',$data['id']);
                $this->db->update('tbl_slider');
        }
        public function upfavcat($data)
        {
                $this->db->set('one',$data['one']);
                $this->db->set('two',$data['two']);
                $this->db->set('three',$data['three']);
                $this->db->set('four',$data['four']);
                $this->db->where('catid',1);
                $this->db->update('tbl_favoritecat');
        }

        public function deletecategory($id)
        {
                $this->db->where('catId',$id);
                $this->db->delete('tbl_category');
        }
        public function delfavcategory($id)
        {
                $this->db->where('id',$id);
                $this->db->delete('tbl_catimage');
        }
        
        public function delcarsoel($id)
        {
                $this->db->where('id',$id);
               
                if ($this->db->delete('tbl_slider')) {
                       return TRUE;
                }else{
                        return FALSE;
                }
        }
}