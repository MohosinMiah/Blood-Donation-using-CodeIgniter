<?php
class userr_model extends CI_Model {
function __construct() {
parent::__construct();
}

  public function insertuser($data)
            {
               $this->db->select('*');
               $this->db->where('email',$data['email']);
               $this->db->from('tbl_user');
               $query = $this->db->get();
               $result = $query->result();
               if ($result) {
                   return true;
               }else{
                $this->db->insert('tbl_user', $data);
               }    
        }

public function deletedonor($usid,$livdis)
{
  $this->db->where('userid',$usid);
  $this->db->where('lidistrict',$livdis);
  if ($this->db->delete('tbl_donor')) {
    return TRUE;
  }
}


public function checkadminemail($data)
{
  $this->db->select('*');
               $this->db->where('email',$data['email']);
               $this->db->from('tbl_user');
               $query = $this->db->get();
               $result = $query->result();
               if ($result) {
                   return TRUE;
               }else{
                return  FALSE;
               }
}


public function checkdonoremail($data)
{
  $this->db->select('*');
               $this->db->where('email',$data['email']);
               $this->db->from('tbl_donor');
               $query = $this->db->get();
               $result = $query->result();
               if ($result) {
                   return TRUE;
               }else{
                return  FALSE;
               }
}


public function updatepassword($data)
{
  $this->db->set('password',$data['pass']);
  $this->db->where('email',$data['email']);
  $this->db->update('tbl_user');
}
public function updatedonorpassword($data)
{
  $this->db->set('password',$data['pass']);
  $this->db->where('email',$data['email']);
  $this->db->update('tbl_donor');
}

public function userlist()
        {
                $this->db->select('*');
                $this->db->from('tbl_user');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }


        public function showuserbyid($id)
        {
                $this->db->select('*');
                $this->db->from('tbl_user');
                $this->db->where('userId',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

  public function checklogin($data)
  {
    $this->db->select('*');
 $this->db->from('tbl_user'); 
     $this->db->where('email',$data['email']); 
    $this->db->where('password',$data['password']);
   
    $conunt =  $this->db->count_all_results();
    if ($conunt>0) {
      $query = $this->db->get();
      $result = $query->result();
        return $result;
    }else{
      return FALSE;
    }
    
  }

//         public function category($catid)
//         {
//                 $this->db->select('*');
//                 $this->db->from('tbl_category');
//                 $this->db->where('catId',$catid);
//                 $query = $this->db->get();
//                 $result = $query->result();
//                 return $result;
//         }
// public function delimg($data)
// {
//         $this->db->select('*');
//         $this->db->from('tbl_post');
//     $this->db->where('postid',$data['postid']);
//     $query =  $this->db->get();
//   $result = $query->result();
//                 foreach ($result as $key => $value) {
//                         $filename = base_url().'uploads/'.basename($value->image);
//                          if (file_exists($filename))
//         {
//             unlink($filename);
//         }
//                 }
// }
        public function updateuser($data)
        {

                
                $this->db->set('name',$data['name']);
                $this->db->set('address',$data['address']);
                $this->db->set('Phone',$data['Phone']);
                $this->db->set('roll',$data['roll']);
                $this->db->where('userId',$data['userId']);
                $this->db->update('tbl_user');
             

         
        }
        

  public function deleteuser($id,$title)
  {
          $this->db->where('userId',$id);
        
          $this->db->delete('tbl_user');
  }
        // public function deletecategory($id)
        // {
        //         $this->db->where('catId',$id);
        //         $this->db->delete('tbl_category');
        // }

}