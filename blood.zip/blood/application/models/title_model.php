<?php
class title_model extends CI_Model {
function __construct() {
parent::__construct();
}

  public function showtitle()
        {
                $this->db->select('*');
                $this->db->from('tbl_title');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }


       

        public function changetitle($data)
        {
                $this->db->set('webtitle',$data['webtitle']);
                $this->db->set('webslang',$data['webslang']);
                $this->db->where('titleid',$data['titleid']);
                $this->db->update('tbl_title');
        }

        

}