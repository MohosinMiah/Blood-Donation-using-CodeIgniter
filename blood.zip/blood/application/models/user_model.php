
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class user_model extends CI_Model {

public function adddonor($data)
{
	$this->db->insert('tbl_donor',$data);
	

}

public function checkemail($data)
{
	$this->db->select('email');
	$this->db->from('tbl_donor');
	// $this->db->where('email',$data['email']);
	$store = $this->db->get();
	$result = $store->num_rows();
	if ($result >= 1) {
		return TRUE;
	}else{
		return FALSE;
	}
}
 public function donorlogin($data)
 {
 	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->where('email',$data['email']);
	$this->db->where('password',$data['password']);
	$store = $this->db->get();
	$numrow = $store->num_rows();
	if ($numrow === 1) {
		$sdata = array();
		$result = $store->result();
		foreach ($result as $key => $userinfo) {
		        $sdata['login']=TRUE;
                     $sdata['name'] = $userinfo->name;
                      $sdata['userid'] = $userinfo->userid;
            $sdata['email'] = $userinfo->email;
			

			
			$this->session->set_userdata($sdata);
		}
	}else{
		return FALSE;
	}
	
 }


public function adminlogin($data)
 {
 	$this->db->select('*');
	$this->db->from('tbl_user');
	$this->db->where('email',$data['email']);
	$this->db->where('password',$data['password']);
	$store = $this->db->get();
	$numrow = $store->num_rows();
	if ($numrow === 1) {
		$sdata = array();
		$result = $store->result();
		foreach ($result as $key => $userinfo) {
		        $sdata['alogin']=TRUE;
                     $sdata['name'] = $userinfo->name;
                     $sdata['roll'] = $userinfo->roll;
                      $sdata['userId'] = $userinfo->userId;
            $sdata['email'] = $userinfo->email;
			

			
			$this->session->set_userdata($sdata);
		}
	}else{
		return FALSE;
	}
	
 }

public function donorinformation($data)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->where('email',$data['email']);
	$this->db->where('userid',$data['userid']);
	$this->db->limit(1);
    $store = $this->db->get();
    $result = $store->result();
    return $result; 


}

public function donorinformationbyid($id)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->where('userid',$id);
	$this->db->limit(1);
    $store = $this->db->get();
    $result = $store->result();
    return $result; 


}


public function alldonorinfo()
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->order_by('userid','DESC');
    $store = $this->db->get();
    $result = $store->result();
    return $result; 
}

public function ralldonarbybgroup($id)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
   $this->db->where('bgroup',$id);
	$this->db->order_by('userid','DESC');
    $store = $this->db->get();
    $result = $store->result();
    return $result; 
}

public function onegroup($id)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
   $this->db->where('bgroup',$id);
   $this->db->limit(1);
    $store = $this->db->get();
    $result = $store->result();
    return $result; 
}
 public function alldistrict()
 {
 	$this->db->select('*');
	$this->db->from('tbl_district');
	$this->db->order_by('name','ASC');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
 }

public function getdiname($id)
{
	$this->db->select('lidistrict');
	$this->db->from('tbl_donor');
	$this->db->where('lidistrict',$id);
	$store = $this->db->get();
	$result = $store->num_rows();
	return $result;
}
 public function alldonorlist()
 {
 	$this->db->select('*');
	$this->db->from('tbl_donor');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
 }

public function sddonors($id)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->where('lidistrict',$id);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function onedis($id)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->where('lidistrict',$id);
	$this->db->limit(1);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}
 public function bloodgroup()
 {
 	$this->db->select('*');
	$this->db->from('tbl_blood');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
 }

public function country()
{
	$this->db->select('*');
	$this->db->from('tbl_country');
	$this->db->order_by('name','ASC');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}




public function updatedonarwi($data)
{
	$this->db->set('name',$data['name']);
	$this->db->set('image',$data['image']);
	$this->db->set('lidistrict',$data['lidistrict']);
	$this->db->set('homdistrict',$data['homdistrict']);
	$this->db->set('contact',$data['contact']);
	$this->db->set('gender',$data['gender']);
	$this->db->set('bdate',$data['bdate']);
	$this->db->set('weight',$data['weight']);
	$this->db->set('smoker',$data['smoker']);
	$this->db->set('drug',$data['drug']);
	$this->db->set('website',$data['website']);
	$this->db->set('about',$data['about']);
	$this->db->set('paddress',$data['paddress']);
	$this->db->set('status',$data['status']);
	$this->db->set('bgroup',$data['bgroup']);
	$this->db->set('hcountry',$data['hcountry']);
	$this->db->set('amessage',$data['amessage']);
	$this->db->where('email',$data['email']);
	$this->db->where('userid',$data['userid']);
	$this->db->update('tbl_donor');
}
public function updatedonarwo($data)
{
	$this->db->set('name',$data['name']);
	// $this->db->set('image',$data['image']);
	$this->db->set('lidistrict',$data['lidistrict']);
	$this->db->set('homdistrict',$data['homdistrict']);
	$this->db->set('contact',$data['contact']);
	$this->db->set('gender',$data['gender']);
	$this->db->set('bdate',$data['bdate']);
	$this->db->set('weight',$data['weight']);
	$this->db->set('smoker',$data['smoker']);
	$this->db->set('drug',$data['drug']);
	$this->db->set('website',$data['website']);
	$this->db->set('about',$data['about']);
	$this->db->set('paddress',$data['paddress']);
	$this->db->set('status',$data['status']);
	$this->db->set('bgroup',$data['bgroup']);
	$this->db->set('hcountry',$data['hcountry']);
	$this->db->set('amessage',$data['amessage']);
	$this->db->where('email',$data['email']);
	$this->db->where('userid',$data['userid']);
	$this->db->update('tbl_donor');
}

public function passchange($data)
{
   $this->db->set('password',$data['upassword']);
	$this->db->where('userid',$data['userid']);
	$this->db->update('tbl_donor');

}


public function adminpasschange($data)
{
   $this->db->set('password',$data['upassword']);
	$this->db->where('userId',$data['userId']);
	$this->db->update('tbl_user');

}



public function adddondata($data)
{
	$this->db->insert('tbl_donhistri',$data);
	

}
public function addrequest($data)
{
	$this->db->insert('tbl_request',$data);
	

}

public function limitrequest()
{
	$this->db->select('*');
	$this->db->from('tbl_request');
	$this->db->order_by('id','DESC');
	$this->db->limit(6);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function allrequest()
{
	$this->db->select('*');
	$this->db->from('tbl_request');
	$this->db->order_by('id','DESC');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function history($data)
{
	$this->db->select('*');
	$this->db->from('tbl_donhistri');
	$this->db->where('userid',$data['userid']);
	$this->db->order_by('id','DESC');
	// $this->db->limit(15);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}


public function lastd($data)
{
	$this->db->select('*');
	$this->db->from('tbl_donhistri');
	$this->db->where('userid',$data['userid']);
	$this->db->order_by('id','DESC');
	$this->db->limit(1);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}


public function totalhis($data)
{
	$this->db->select('id');
	$this->db->from('tbl_donhistri');
	$this->db->where('userid',$data['userid']);
	$store = $this->db->get();
	$result = $store->num_rows();
	$this->session->set_userdata('tohistory',$result);
}

public function hitosyid($usid)
{
	$this->db->select('id');
	$this->db->from('tbl_donhistri');
	$this->db->where('userid',$usid);
	$store = $this->db->get();
	$result = $store->num_rows();
	$this->session->set_userdata('tohistoryid',$result);
}

public function getemail($data)
{
	$this->db->select('*');
	$this->db->from('tbl_donor');
	$this->db->where('userid',$data['userid']);
	$store = $this->db->get();
	$result = $store->result();
	if (isset($result)) {
		foreach ($result as  $m) {
		$this->session->set_userdata('sendmail',$m->email);
	}
	}
	
}
	public function savemessage($adata)
	{ 
		
		$this->db->insert('tbl_message',$adata);
	}

// Bolood Donation 

public function authorlist()
{
	$this->db->select('*');
	$this->db->from('tbl_author');
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function showauthorbyid($id)
{
	$this->db->select('*');
	$this->db->from('tbl_author');
	$this->db->where('author_id',$id);
	$store = $this->db->get();
	$result = $store->result();
	return $result;
}

public function updateauthorin($data)
{
	$this->db->set('author_name',$data['author_name']);
	$this->db->where('author_id',$data['author_id']);
	$this->db->update('tbl_author');
}

public function deleteauthor($id)
{
	$this->db->where('author_id',$id);
	$this->db->delete('tbl_author');
}

}