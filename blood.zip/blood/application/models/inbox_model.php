<?php
class inbox_model extends CI_Model {
function __construct() {
parent::__construct();
}

        // public function insertcategory($data)
        // {
        
        //         $this->db->insert('tbl_category', $data);
        // }
        
   public function sendmessage($data)
   {
           $this->db->insert('tbl_email', $data);
   }

        public function inboxmessagelist()
        {
                $this->db->select('*');
                $this->db->from('tbl_email');
                $this->db->where('starus',2);
                $this->db->order_by('id', 'DESC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
public function seeninboxmessagelist()
{
    $this->db->select('*');
                $this->db->from('tbl_email');
                $this->db->where('starus',3);
                $this->db->order_by('id', 'DESC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
}
 public function viewemail($id)
 {
     $this->db->select('*');
                $this->db->from('tbl_email');
                $this->db->where('id',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
 }

 public function seenmsg($data)
 {
  
     $this->db->set('starus',3);
     $this->db->where('id',$data['id']);
     $this->db->update('tbl_email');
 }

public function deletemsg($id)
{
            $this->db->where('id',$id);
                $this->db->delete('tbl_email');
}

public function emailget($id)
{
    $this->db->select('*');
                $this->db->from('tbl_email');
                $this->db->where('id',$id);
                $this->db->limit(1);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
}


public function totalseenmsg()
{
     $this->db->where('starus',2);
     $this->db->from('tbl_email');
    return  $this->db->count_all_results();
}
        // public function showcatbyid($id)
        // {
        //         $this->db->select('*');
        //         $this->db->from('tbl_category');
        //         $this->db->where('catId',$id);
        //         $query = $this->db->get();
        //         $result = $query->result();
        //         return $result;
        // }

        // public function updatecategory($data)
        // {
        //         $this->db->set('catname',$data['catname']);
        //         $this->db->where('catId',$data['catId']);
        //         $this->db->update('tbl_category');
        // }

        // public function deletecategory($id)
        // {
        //         $this->db->where('catId',$id);
        //         $this->db->delete('tbl_category');
        // }

}