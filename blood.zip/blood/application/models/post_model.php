<?php
class post_model extends CI_Model {
function __construct() {
parent::__construct();
}
public function index()
  {
    $data['countallunseenmsg']= $this->inbox_model->totalseenmsg();
    $data['allPages'] = $this->pages_model->pages();
    $data['title'] = 'Big store a Ecommerce Online Shopping';
    $data['titleoption'] = $this->title_model->showtitle();
    $data['mediaoption'] = $this->media_model->showmedia();
    $data['header']=$this->load->view('font/inc/header',$data,TRUE);
    $data['sidebar']=$this->load->view('font/inc/sidebar','',TRUE);
    $data['catlist'] = $this->category_model->categorylist();
            $data['postlist'] = $this->post_model->postlist();

$data['copyright'] = $this->media_model->showcopyright();
    $data['main']=$this->load->view('font/home/home',$data,TRUE);
    $data['footer']=$this->load->view('font/home/footer',$data,TRUE);
    $this->load->view('font/home',$data);
  }
public function searchposts($data)
{
    $this->db->select('*');
                $this->db->from('tbl_product');

               $this->db->like('title', $data['keyword']); 
               $this->db->or_like('body', $data['keyword']);
               $this->db->or_like('postdate', $data['keyword']);
               $this->db->or_like('image', $data['keyword']);
               $this->db->or_like('author', $data['keyword']);
                $query = $this->db->get();
                $result = $query->result();
                if ($result) {
                    return $result;
                }else{
                    return FALSE;
                }
                
}
        public function insertpost($data)
        {
        
                $this->db->insert('tbl_product', $data);
        }

        public function postlist()
        {
                $this->db->select('*');
                $this->db->from('tbl_product');
               $this->db->order_by('postid', 'DESC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function firstcatall()
        {
          $this->db->select('*');
                $this->db->from('tbl_product');
               $this->db->order_by('postid', 'DESC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function sperialproduct()
        {
            $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('status',3);
                $this->db->limit(8);
               $this->db->order_by('postid', 'DESC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
         public function allsperialproduct()
        {
            $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('status',3);
                $this->db->limit(20);
               $this->db->order_by('postid', 'ASC');
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
     public function favcatone($data)
     {
         $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$data['favcatid']);
               $this->db->limit(4);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
     }

   public function favcatidtwo($data)
     {
         $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$data['favtwo']);
               $this->db->limit(4);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
     }
 public function catidfr($catidfr)
 {
   $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$catidfr);
               $this->db->limit(4);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
 }
     public function showprobycatid($two)
     {
       $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$two);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
     }
     public function showprobycatidd($two)
     {
       $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postid',$two);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
     }

   public function favcatidthree($data)
     {
                $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$data['favthree']);
                $this->db->limit(4);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
     }
   public function favcatidfour($data)
     {
                $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$data['favfour']);
                $this->db->limit(4);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
     }

  public function allprodetails()
  {
     $this->db->select('*');
                $this->db->from('tbl_product');
                
                $query = $this->db->get();
                $result = $query->result();
                return $result;
  }
        public function showposbyid($id)
        {
                $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postid',$id);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }

        public function category($catid)
        {
                $this->db->select('*');
                $this->db->from('tbl_category');
                $this->db->where('catId',$catid);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
        }
public function delimg($data)
{
        $this->db->select('*');
        $this->db->from('tbl_product');
    $this->db->where('postid',$data['postid']);
    $query =  $this->db->get();
  $result = $query->result();
                foreach ($result as $key => $value) {
                        $filename = base_url().'uploads/'.basename($value->image);
                         if (file_exists($filename))
        {
            unlink($filename);
        }
                }
}
        public function updatepost($data)
        {
  
         
                $this->db->set('title',$data['title']);
                $this->db->set('postcat',$data['postcat']);
                $this->db->set('body',$data['body']);
                $this->db->set('author',$data['author']);
                $this->db->set('status',$data['status']);
                $this->db->set('image',$data['image']);
                $this->db->where('postid',$data['postid']);
                $this->db->update('tbl_product');
        }
        

  public function delpost($id,$title)
  {
          $this->db->where('postid',$id);
          $this->db->where('title',$title);
          $this->db->delete('tbl_product');
  }
       
// view start here 

  public function single($title)
  {
               $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postid',$title);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
  }

public function postsbycat($catId)
{
    $this->db->select('*');
                $this->db->from('tbl_product');
                $this->db->where('postcat',$catId);
                $query = $this->db->get();
                $result = $query->result();
                return $result;
}





}